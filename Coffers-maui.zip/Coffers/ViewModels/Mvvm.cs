using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace Coffers.ViewModels;

public abstract class Observable : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected void Raise([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    protected void RaiseAll(params string[] names)
    {
        foreach (var n in names) Raise(n);
    }

    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        Raise(name);
        return true;
    }
}

public class Relay : ICommand
{
    private readonly Action<object?> _run;
    private readonly Func<object?, bool>? _can;

    public Relay(Action run, Func<bool>? can = null)
    {
        _run = _ => run();
        _can = can is null ? null : _ => can();
    }

    public Relay(Action<object?> run, Func<object?, bool>? can = null)
    {
        _run = run;
        _can = can;
    }

    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => _can?.Invoke(parameter) ?? true;
    public void Execute(object? parameter) => _run(parameter);
    public void Refresh() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}

public class AsyncRelay : ICommand
{
    private readonly Func<object?, Task> _run;
    private bool _busy;

    public AsyncRelay(Func<Task> run) => _run = _ => run();
    public AsyncRelay(Func<object?, Task> run) => _run = run;

    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => !_busy;

    public async void Execute(object? parameter)
    {
        if (_busy) return;
        _busy = true;
        CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        try { await _run(parameter); }
        finally
        {
            _busy = false;
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
