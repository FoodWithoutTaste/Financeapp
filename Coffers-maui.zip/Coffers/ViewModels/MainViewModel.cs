using System.Collections.ObjectModel;
using Coffers.Drawables;
using Coffers.Models;
using Coffers.Services;

namespace Coffers.ViewModels;

public record TxRow(Transaction Tx, string CategoryLabel, Color CategoryColor,
                    Color CategoryTint, string Note, string AmountText, Color AmountColor)
{
    public bool HasNote => !string.IsNullOrWhiteSpace(Note);
}

public record DayGroup(string Label, string TotalText, List<TxRow> Rows);

public record GoalRow(string Name, string NumsText, double Progress, string MetaText);

public record NoteRow(string Text, Brush Dot);

public class MainViewModel : Observable
{
    private readonly BookStore _store = new();

    public Book Book { get; private set; } = new();

    public MainViewModel()
    {
        PrevMonthCommand  = new Relay(() => Month = Insights.ShiftMonth(Month, -1));
        NextMonthCommand  = new Relay(() => { if (CanGoForward) Month = Insights.ShiftMonth(Month, 1); });
        QuietDayCommand   = new AsyncRelay(MarkQuietDayAsync);
        ShareCommand      = new AsyncRelay(() => _store.ShareCsvAsync(Book));
        EditCommand       = new Relay(p =>
        {
            if (p is TxRow row) EditRequested?.Invoke(row.Tx);
        });
    }

    public Relay PrevMonthCommand { get; }
    public Relay NextMonthCommand { get; }
    public AsyncRelay QuietDayCommand { get; }
    public AsyncRelay ShareCommand { get; }
    public Relay EditCommand { get; }

    /// <summary>Raised when a row is tapped. The page handles navigation, not the view model.</summary>
    public event Action<Transaction>? EditRequested;

    public string ToCsv() => BookStore.ToCsv(Book);
    public string ToJson() => BookStore.ToJson(Book);
    public Task ShareCsvAsync() => _store.ShareCsvAsync(Book);

    public async Task<bool> RestoreAsync(string json)
    {
        var restored = BookStore.FromJson(json);
        if (restored is null) return false;
        Book = restored;
        await SaveAsync();
        return true;
    }

    // ---------- state ----------

    private string _month = DateTime.Today.ToString("yyyy-MM");
    public string Month
    {
        get => _month;
        set { if (Set(ref _month, value)) Recalculate(); }
    }

    private string _status = "";
    public string Status { get => _status; set => Set(ref _status, value); }

    public bool HasStatus => !string.IsNullOrEmpty(Status);

    private bool _busy = true;
    public bool Busy { get => _busy; set => Set(ref _busy, value); }

    // ---------- loading & saving ----------

    public async Task LoadAsync()
    {
        Busy = true;
        Book = await _store.LoadAsync();
        if (!string.IsNullOrEmpty(_store.LastError)) Status = _store.LastError;
        Busy = false;
        Recalculate();
    }

    public async Task SaveAsync()
    {
        var ok = await _store.SaveAsync(Book);
        Status = ok ? "" : _store.LastError;
        Raise(nameof(HasStatus));
        Recalculate();
    }

    public async Task AddOrUpdateAsync(Transaction tx)
    {
        var existing = Book.Transactions.FirstOrDefault(t => t.Id == tx.Id);
        if (existing is not null) Book.Transactions.Remove(existing);
        Book.Transactions.Add(tx);
        Month = tx.Date[..7];
        await SaveAsync();
    }

    public async Task DeleteAsync(string id)
    {
        Book.Transactions.RemoveAll(t => t.Id == id);
        await SaveAsync();
    }

    private async Task MarkQuietDayAsync()
    {
        var today = DateTime.Today.ToString("yyyy-MM-dd");
        if (Book.QuietDays.Contains(today)) return;
        Book.QuietDays.Add(today);
        await SaveAsync();
    }

    // ---------- derived, all recomputed together ----------

    public string Currency => Book.Settings.Currency;

    public string BalanceText { get; private set; } = "—";
    public string InText { get; private set; } = "—";
    public string OutText { get; private set; } = "—";
    public string NetText { get; private set; } = "—";
    public Color NetColor { get; private set; } = Palette.Ink;

    public string MonthName { get; private set; } = "";
    public bool CanGoForward { get; private set; }

    public string RunwayText { get; private set; } = "—";
    public string RunwayFoot { get; private set; } = "";
    public RunwayWedge Wedge { get; } = new();

    public string StreakText { get; private set; } = "";
    public bool ShowQuietButton { get; private set; }

    public ObservableCollection<GoalRow> Goals { get; } = new();
    public ObservableCollection<NoteRow> Notes { get; } = new();
    public ObservableCollection<DayGroup> Days { get; } = new();

    public bool HasNotes => Notes.Count > 0;
    public bool HasEntries => Days.Count > 0;
    public bool HasCatData { get; private set; }

    public CategoryBarChart CatChart { get; } = new();
    public PaceChart Pace { get; } = new();
    public double CatChartHeight { get; private set; } = 40;

    public event Action? ChartsChanged;

    public void Recalculate()
    {
        var cur = Book.Settings.Currency;
        var today = DateTime.Today;
        var todayKey = today.ToString("yyyy-MM-dd");

        // --- balance ---
        var balance = Book.Settings.Opening + Book.Transactions.Sum(t => t.Signed);
        BalanceText = Money.Format(balance, cur);

        // --- this month ---
        var month = Book.Transactions.Where(t => t.Date.StartsWith(Month)).ToList();
        var mIn = month.Where(t => t.Type == Flow.In).Sum(t => t.Amount);
        var mOut = month.Where(t => t.Type == Flow.Out).Sum(t => t.Amount);
        InText = Money.Format(mIn, cur);
        OutText = Money.Format(mOut, cur);
        NetText = Money.Format(mIn - mOut, cur);
        NetColor = mIn - mOut >= 0 ? Palette.In : Palette.Out;

        MonthName = Insights.PrettyMonth(Month);
        CanGoForward = string.CompareOrdinal(Month, today.ToString("yyyy-MM")) < 0;

        // --- burn rate over the last 30 days ---
        var cutoff = today.AddDays(-29);
        var recent = Book.Transactions
            .Where(t => t.Type == Flow.Out && t.When >= cutoff && t.When <= today)
            .ToList();

        decimal burn = 0m;
        if (recent.Count > 0)
        {
            var earliest = recent.Min(t => t.When);
            var span = Math.Max(1, (today - earliest).Days + 1);
            burn = recent.Sum(t => t.Amount) / span;
        }

        if (burn > 0)
        {
            var days = (int)Math.Floor(balance / burn);
            RunwayText = days > 365 ? "Over a year" : $"{days} {(days == 1 ? "day" : "days")}";
            RunwayFoot = $"Burning {Money.Format(burn, cur)} a day. That's how long the coffers last if nothing changes.";
            Wedge.HasData = true;
            Wedge.Fraction = Math.Clamp((float)days / 120f, 0f, 1f);
        }
        else
        {
            RunwayText = "—";
            RunwayFoot = "Record a few payments and this will show how long your money lasts.";
            Wedge.HasData = false;
            Wedge.Fraction = 0f;
        }

        // --- streak ---
        var logged = new HashSet<string>(Book.Transactions.Select(t => t.Date));
        foreach (var q in Book.QuietDays) logged.Add(q);

        var streak = 0;
        var cursor = today;
        while (logged.Contains(cursor.ToString("yyyy-MM-dd")) && streak < 999)
        {
            streak++;
            cursor = cursor.AddDays(-1);
        }
        StreakText = streak > 0
            ? $"Recorded {streak} {(streak == 1 ? "night" : "nights")} running"
            : "Nothing recorded yet today";
        ShowQuietButton = !logged.Contains(todayKey);

        // --- goals ---
        Goals.Clear();
        foreach (var g in Book.Goals)
        {
            var pct = g.Target > 0 ? Math.Clamp((double)(g.Saved / g.Target), 0, 1) : 0;
            string meta;
            if (pct >= 1) meta = "Funded.";
            else if (mIn - mOut > 0)
            {
                var months = (int)Math.Ceiling((g.Target - g.Saved) / (mIn - mOut));
                meta = $"About {months} {(months == 1 ? "month" : "months")} at this month's pace";
            }
            else meta = "Set a positive month to see a finish date";

            Goals.Add(new GoalRow(
                g.Name,
                $"{Money.Format(g.Saved, cur)} / {Money.Format(g.Target, cur)}",
                pct, meta));
        }

        // --- notes ---
        Notes.Clear();
        foreach (var n in Insights.For(Book, Month))
        {
            var dot = n.Tone switch
            {
                Tone.Warn => Palette.Out,
                Tone.Good => Palette.In,
                _ => Palette.Muted,
            };
            Notes.Add(new NoteRow(n.Text, new SolidColorBrush(dot)));
        }

        // --- category chart ---
        CatChart.Format = v => Money.Format(v, cur);
        CatChart.Slices = month
            .Where(t => t.Type == Flow.Out)
            .GroupBy(t => t.Category)
            .Select(g => new CatSlice(
                Categories.Find(g.Key).Label,
                g.Sum(x => x.Amount),
                Categories.ColorOf(g.Key)))
            .OrderByDescending(s => s.Value)
            .ToList();
        HasCatData = CatChart.Slices.Count > 0;
        CatChartHeight = Math.Max(40, CatChart.Slices.Count * CategoryBarChart.RowHeight);

        // --- pace chart ---
        var year = int.Parse(Month[..4]);
        var mo = int.Parse(Month[5..7]);
        var daysInMonth = DateTime.DaysInMonth(year, mo);
        var prevKey = Insights.ShiftMonth(Month, -1);

        List<decimal> Cumulative(string key, int upTo)
        {
            var rows = Book.Transactions
                .Where(t => t.Type == Flow.Out && t.Date.StartsWith(key))
                .ToList();
            var acc = new List<decimal>();
            decimal running = 0m;
            for (var d = 1; d <= upTo; d++)
            {
                running += rows.Where(t => int.Parse(t.Date[8..]) == d).Sum(t => t.Amount);
                acc.Add(running);
            }
            return acc;
        }

        Pace.Current = Cumulative(Month, daysInMonth);
        Pace.Previous = Cumulative(prevKey, daysInMonth);

        // --- entries, newest day first ---
        Days.Clear();
        foreach (var g in month
                     .OrderByDescending(t => t.Date)
                     .GroupBy(t => t.Date))
        {
            var rows = g.Select(t =>
            {
                var cat = Categories.Find(t.Category);
                var color = Color.FromArgb(cat.Hex);
                return new TxRow(
                    t, cat.Label, color, color.WithAlpha(0.12f),
                    t.Note ?? "",
                    (t.Type == Flow.In ? "+" : "−") + Money.Format(t.Amount, cur),
                    t.Type == Flow.In ? Palette.In : Palette.Ink);
            }).ToList();

            Days.Add(new DayGroup(
                DayLabel(g.Key),
                Money.Format(g.Sum(t => t.Signed), cur),
                rows));
        }

        RaiseAll(nameof(BalanceText), nameof(InText), nameof(OutText), nameof(NetText),
                 nameof(NetColor), nameof(MonthName), nameof(CanGoForward),
                 nameof(RunwayText), nameof(RunwayFoot), nameof(StreakText),
                 nameof(ShowQuietButton), nameof(HasNotes), nameof(HasEntries),
                 nameof(HasCatData), nameof(CatChartHeight), nameof(Currency),
                 nameof(HasStatus));

        ChartsChanged?.Invoke();
    }

    private static string DayLabel(string date)
    {
        var d = DateTime.ParseExact(date, "yyyy-MM-dd", null);
        if (d == DateTime.Today) return "Today";
        if (d == DateTime.Today.AddDays(-1)) return "Yesterday";
        return d.ToString("ddd d MMM");
    }
}
