using System.Collections.ObjectModel;
using Coffers.Drawables;
using Coffers.Models;
using Coffers.Services;

namespace Coffers.ViewModels;

public record TxRow(Transaction Tx, string CategoryLabel, Color CategoryColor,
                    Color CategoryTint, string Note, string AmountText, Color AmountColor);

public record DayGroup(string Label, string TotalText, List<TxRow> Rows);

public record GoalRow(string Name, string NumsText, double Progress, string MetaText);

public record NoteRow(string Text, Brush Dot);

public record BudgetRow(string Label, string NumsText, double Progress, Color Bar, string MetaText);

public record StatRow(string Caption, string Value);

/// <summary>A payment you make often enough that typing it again is a waste of your evening.</summary>
public record QuickEntry(string Label, string Detail, Flow Type, decimal Amount,
                         string Category, string Note, Color Hue);

public class MainViewModel : Observable
{
    private readonly BookStore _store = new();
    private Transaction? _lastDeleted;

    public Book Book { get; private set; } = new();

    public MainViewModel()
    {
        PrevMonthCommand   = new Relay(() => Month = Insights.ShiftMonth(Month, -1));
        NextMonthCommand   = new Relay(() => { if (CanGoForward) Month = Insights.ShiftMonth(Month, 1); });
        ThisMonthCommand   = new Relay(() => Month = DateTime.Today.ToString("yyyy-MM"));
        ClearSearchCommand = new Relay(() => SearchText = "");
        QuietDayCommand    = new AsyncRelay(MarkQuietDayAsync);
        UndoCommand        = new AsyncRelay(UndoDeleteAsync);
    }

    public Relay PrevMonthCommand { get; }
    public Relay NextMonthCommand { get; }
    public Relay ThisMonthCommand { get; }
    public Relay ClearSearchCommand { get; }
    public AsyncRelay QuietDayCommand { get; }
    public AsyncRelay UndoCommand { get; }

    // ---------- state ----------

    private string _month = DateTime.Today.ToString("yyyy-MM");
    public string Month
    {
        get => _month;
        set { if (Set(ref _month, value)) Recalculate(); }
    }

    private string _searchText = "";
    public string SearchText
    {
        get => _searchText;
        set { if (Set(ref _searchText, value)) Recalculate(); }
    }

    private string _status = "";
    public string Status
    {
        get => _status;
        set { Set(ref _status, value); Raise(nameof(HasStatus)); }
    }
    public bool HasStatus => !string.IsNullOrEmpty(Status);

    private bool _busy = true;
    public bool Busy { get => _busy; set => Set(ref _busy, value); }

    public bool CanUndo => _lastDeleted is not null;

    // ---------- loading & saving ----------

    public async Task LoadAsync()
    {
        Busy = true;
        Book = await _store.LoadAsync();
        if (!string.IsNullOrEmpty(_store.LastError)) Status = _store.LastError;
        Busy = false;
        ApplyReminder();
        Recalculate();
    }

    public async Task SaveAsync()
    {
        var ok = await _store.SaveAsync(Book);
        Status = ok ? "" : _store.LastError;
        Recalculate();
    }

    public void ApplyReminder()
    {
        if (Book.Reminder.Enabled) Reminders.Schedule(Book.Reminder.Hour, Book.Reminder.Minute);
        else Reminders.Cancel();
    }

    public async Task AddOrUpdateAsync(Transaction tx)
    {
        var existing = Book.Transactions.FirstOrDefault(t => t.Id == tx.Id);
        if (existing is not null) Book.Transactions.Remove(existing);
        Book.Transactions.Add(tx);
        _month = tx.Date[..7];
        Raise(nameof(Month));
        await SaveAsync();
    }

    public async Task DeleteAsync(string id)
    {
        _lastDeleted = Book.Transactions.FirstOrDefault(t => t.Id == id);
        Book.Transactions.RemoveAll(t => t.Id == id);
        await SaveAsync();
    }

    private async Task UndoDeleteAsync()
    {
        if (_lastDeleted is null) return;
        Book.Transactions.Add(_lastDeleted);
        _lastDeleted = null;
        await SaveAsync();
    }

    public void DismissUndo()
    {
        _lastDeleted = null;
        Raise(nameof(CanUndo));
    }

    private async Task MarkQuietDayAsync()
    {
        var today = DateTime.Today.ToString("yyyy-MM-dd");
        if (Book.QuietDays.Contains(today)) return;
        Book.QuietDays.Add(today);
        await SaveAsync();
    }

    public string ToCsv() => BookStore.ToCsv(Book);
    public string ToJson() => BookStore.ToJson(Book);
    public Task ShareCsvAsync() => _store.ShareCsvAsync(Book);

    public async Task<bool> RestoreAsync(string json)
    {
        var restored = BookStore.FromJson(json);
        if (restored is null) return false;
        Book = restored;
        await SaveAsync();
        ApplyReminder();
        return true;
    }

    // ---------- derived ----------

    public string Currency => Book.Settings.Currency;

    public string BalanceText { get; private set; } = "—";
    public string InText { get; private set; } = "—";
    public string OutText { get; private set; } = "—";
    public string NetText { get; private set; } = "—";
    public Color NetColor { get; private set; } = Palette.Ink;

    public string MonthName { get; private set; } = "";
    public bool CanGoForward { get; private set; }
    public bool NotThisMonth { get; private set; }

    public string RunwayText { get; private set; } = "—";
    public string RunwayFoot { get; private set; } = "";
    public RunwayWedge Wedge { get; } = new();

    public string StreakText { get; private set; } = "";
    public bool ShowQuietButton { get; private set; }

    public ObservableCollection<GoalRow> Goals { get; } = new();
    public ObservableCollection<NoteRow> Notes { get; } = new();
    public ObservableCollection<DayGroup> Days { get; } = new();
    public ObservableCollection<BudgetRow> Budgets { get; } = new();
    public ObservableCollection<StatRow> Stats { get; } = new();

    public bool HasNotes => Notes.Count > 0;
    public bool HasEntries => Days.Count > 0;
    public bool HasBudgets => Budgets.Count > 0;
    public bool HasStats => Stats.Count > 0;
    public bool HasCatData { get; private set; }
    public bool Searching => !string.IsNullOrWhiteSpace(SearchText);
    public string EmptyText { get; private set; } = "";

    public CategoryBarChart CatChart { get; } = new();
    public PaceChart Pace { get; } = new();
    public BalanceChart Balance { get; } = new();
    public double CatChartHeight { get; private set; } = 40;

    public event Action? ChartsChanged;

    /// <summary>The payments you repeat most, for one-tap logging on the entry screen.</summary>
    public List<QuickEntry> QuickEntries()
    {
        var cur = Book.Settings.Currency;

        return Book.Transactions
            .Where(t => t.When >= DateTime.Today.AddDays(-120))
            .GroupBy(t => new
            {
                t.Type,
                t.Category,
                Amount = Math.Round(t.Amount, 0),
                Note = (t.Note ?? "").Trim().ToLowerInvariant(),
            })
            .Where(g => g.Count() >= 2)
            .OrderByDescending(g => g.Count())
            .ThenByDescending(g => g.Max(t => t.Date))
            .Take(6)
            .Select(g =>
            {
                var sample = g.First();
                var cat = Categories.Find(sample.Category);
                var label = string.IsNullOrWhiteSpace(sample.Note) ? cat.Label : sample.Note!;
                return new QuickEntry(label, Money.Format(g.Key.Amount, cur),
                    g.Key.Type, g.Key.Amount, sample.Category, sample.Note ?? "",
                    Color.FromArgb(cat.Hex));
            })
            .ToList();
    }

    public void Recalculate()
    {
        var cur = Book.Settings.Currency;
        var today = DateTime.Today;
        var todayKey = today.ToString("yyyy-MM-dd");

        var balance = Book.Settings.Opening + Book.Transactions.Sum(t => t.Signed);
        BalanceText = Money.Format(balance, cur);

        var month = Book.Transactions.Where(t => t.Date.StartsWith(Month)).ToList();
        var spent = month.Where(t => t.Type == Flow.Out).ToList();
        var mIn = month.Where(t => t.Type == Flow.In).Sum(t => t.Amount);
        var mOut = spent.Sum(t => t.Amount);

        InText = Money.Format(mIn, cur);
        OutText = Money.Format(mOut, cur);
        NetText = Money.Format(mIn - mOut, cur);
        NetColor = mIn - mOut >= 0 ? Palette.In : Palette.Out;

        MonthName = Insights.PrettyMonth(Month);
        CanGoForward = string.CompareOrdinal(Month, today.ToString("yyyy-MM")) < 0;
        NotThisMonth = Month != today.ToString("yyyy-MM");

        // --- burn rate & runway ---
        var cutoff = today.AddDays(-29);
        var recent = Book.Transactions
            .Where(t => t.Type == Flow.Out && t.When >= cutoff && t.When <= today)
            .ToList();

        decimal burn = 0m;
        if (recent.Count > 0)
        {
            var earliest = recent.Min(t => t.When);
            var span = Math.Max(1, (today - earliest).Days + 1);
            burn = recent.Sum(t => t.Amount) / span;
        }

        if (burn > 0)
        {
            var days = (int)Math.Floor(balance / burn);
            RunwayText = days > 365 ? "Over a year" : $"{days} {(days == 1 ? "day" : "days")}";
            RunwayFoot = $"Burning {Money.Format(burn, cur)} a day. That's how long the coffers last if nothing changes.";
            Wedge.HasData = true;
            Wedge.Fraction = Math.Clamp((float)days / 120f, 0f, 1f);
        }
        else
        {
            RunwayText = "—";
            RunwayFoot = "Record a few payments and this will show how long your money lasts.";
            Wedge.HasData = false;
            Wedge.Fraction = 0f;
        }

        // --- streak ---
        var logged = new HashSet<string>(Book.Transactions.Select(t => t.Date));
        foreach (var q in Book.QuietDays) logged.Add(q);

        var streak = 0;
        var cursor = today;
        while (logged.Contains(cursor.ToString("yyyy-MM-dd")) && streak < 999)
        {
            streak++;
            cursor = cursor.AddDays(-1);
        }
        StreakText = streak > 0
            ? $"Recorded {streak} {(streak == 1 ? "night" : "nights")} running"
            : "Nothing recorded yet today";
        ShowQuietButton = !logged.Contains(todayKey);

        // --- stats ---
        Stats.Clear();
        if (spent.Count > 0)
        {
            var dayCount = Month == today.ToString("yyyy-MM")
                ? today.Day
                : DateTime.DaysInMonth(int.Parse(Month[..4]), int.Parse(Month[5..7]));

            Stats.Add(new StatRow("A DAY", Money.Format(mOut / dayCount, cur)));
            Stats.Add(new StatRow("BIGGEST", Money.Format(spent.Max(t => t.Amount), cur)));
            Stats.Add(new StatRow("ENTRIES", month.Count.ToString()));
        }

        // --- budgets ---
        Budgets.Clear();
        foreach (var b in Book.Budgets.Where(x => x.Monthly > 0).OrderByDescending(x => x.Monthly))
        {
            var used = spent.Where(t => t.Category == b.Category).Sum(t => t.Amount);
            var pct = Math.Clamp((double)(used / b.Monthly), 0, 1);
            var over = used > b.Monthly;

            Budgets.Add(new BudgetRow(
                Categories.Find(b.Category).Label,
                $"{Money.Format(used, cur)} / {Money.Format(b.Monthly, cur)}",
                pct,
                over ? Palette.Out : pct > 0.85 ? Color.FromArgb("#C77E23") : Palette.Ink,
                over ? $"{Money.Format(used - b.Monthly, cur)} over"
                     : $"{Money.Format(b.Monthly - used, cur)} left"));
        }

        // --- goals ---
        Goals.Clear();
        foreach (var g in Book.Goals)
        {
            var pct = g.Target > 0 ? Math.Clamp((double)(g.Saved / g.Target), 0, 1) : 0;
            string meta;
            if (pct >= 1) meta = "Funded.";
            else if (mIn - mOut > 0)
            {
                var months = (int)Math.Ceiling((g.Target - g.Saved) / (mIn - mOut));
                meta = $"About {months} {(months == 1 ? "month" : "months")} at this month's pace";
            }
            else meta = "Set a positive month to see a finish date";

            Goals.Add(new GoalRow(g.Name,
                $"{Money.Format(g.Saved, cur)} / {Money.Format(g.Target, cur)}", pct, meta));
        }

        // --- notes ---
        Notes.Clear();
        foreach (var n in Insights.For(Book, Month))
        {
            var dot = n.Tone switch
            {
                Tone.Warn => Palette.Out,
                Tone.Good => Palette.In,
                _ => Palette.Muted,
            };
            Notes.Add(new NoteRow(n.Text, new SolidColorBrush(dot)));
        }

        // --- category chart ---
        CatChart.Format = v => Money.Format(v, cur);
        CatChart.Slices = spent
            .GroupBy(t => t.Category)
            .Select(g => new CatSlice(Categories.Find(g.Key).Label,
                                      g.Sum(x => x.Amount),
                                      Categories.ColorOf(g.Key)))
            .OrderByDescending(s => s.Value)
            .ToList();
        HasCatData = CatChart.Slices.Count > 0;
        CatChartHeight = Math.Max(40, CatChart.Slices.Count * CategoryBarChart.RowHeight);

        // --- pace chart ---
        var year = int.Parse(Month[..4]);
        var mo = int.Parse(Month[5..7]);
        var daysInMonth = DateTime.DaysInMonth(year, mo);

        List<decimal> Cumulative(string key, int upTo)
        {
            var rows = Book.Transactions.Where(t => t.Type == Flow.Out && t.Date.StartsWith(key)).ToList();
            var acc = new List<decimal>();
            decimal running = 0m;
            for (var d = 1; d <= upTo; d++)
            {
                running += rows.Where(t => int.Parse(t.Date[8..]) == d).Sum(t => t.Amount);
                acc.Add(running);
            }
            return acc;
        }

        Pace.Current = Cumulative(Month, daysInMonth);
        Pace.Previous = Cumulative(Insights.ShiftMonth(Month, -1), daysInMonth);

        // --- balance across the last twelve months ---
        var values = new List<decimal>();
        var labels = new List<string>();
        for (var i = 11; i >= 0; i--)
        {
            var mk = Insights.ShiftMonth(Month, -i);
            var cap = mk + "-32";   // sorts above every real date in that month
            values.Add(Book.Settings.Opening
                     + Book.Transactions.Where(t => string.CompareOrdinal(t.Date, cap) < 0)
                                        .Sum(t => t.Signed));
            labels.Add(Insights.PrettyMonth(mk)[..3] + " " + mk[2..4]);
        }
        Balance.Values = values;
        Balance.Labels = labels;
        Balance.Format = v => Money.Format(v, cur);

        // --- entries, filtered and grouped ---
        IEnumerable<Transaction> visible = month;
        if (Searching)
        {
            var q = SearchText.Trim().ToLowerInvariant();
            visible = visible.Where(t =>
                (t.Note ?? "").ToLowerInvariant().Contains(q)
                || Categories.Find(t.Category).Label.ToLowerInvariant().Contains(q)
                || t.Amount.ToString("0.##").Contains(q));
        }

        Days.Clear();
        foreach (var g in visible.OrderByDescending(t => t.Date).GroupBy(t => t.Date))
        {
            var rows = g.Select(t =>
            {
                var cat = Categories.Find(t.Category);
                var hue = Color.FromArgb(cat.Hex);
                return new TxRow(t, cat.Label, hue, hue.WithAlpha(0.12f),
                    t.Note ?? "",
                    (t.Type == Flow.In ? "+" : "−") + Money.Format(t.Amount, cur),
                    t.Type == Flow.In ? Palette.In : Palette.Ink);
            }).ToList();

            Days.Add(new DayGroup(DayLabel(g.Key), Money.Format(g.Sum(t => t.Signed), cur), rows));
        }

        EmptyText = Searching
            ? $"Nothing in {MonthName} matches that."
            : "The page is blank. Tap Record to write the first line.";

        RaiseAll(nameof(BalanceText), nameof(InText), nameof(OutText), nameof(NetText),
                 nameof(NetColor), nameof(MonthName), nameof(CanGoForward), nameof(NotThisMonth),
                 nameof(RunwayText), nameof(RunwayFoot), nameof(StreakText),
                 nameof(ShowQuietButton), nameof(HasNotes), nameof(HasEntries),
                 nameof(HasBudgets), nameof(HasStats), nameof(HasCatData),
                 nameof(CatChartHeight), nameof(Currency), nameof(HasStatus),
                 nameof(CanUndo), nameof(Searching), nameof(EmptyText));

        ChartsChanged?.Invoke();
    }

    private static string DayLabel(string date)
    {
        var d = DateTime.ParseExact(date, "yyyy-MM-dd", null);
        if (d == DateTime.Today) return "Today";
        if (d == DateTime.Today.AddDays(-1)) return "Yesterday";
        return d.ToString("ddd d MMM");
    }
}
