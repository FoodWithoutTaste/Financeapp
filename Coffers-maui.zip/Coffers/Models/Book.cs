using System.Globalization;
using Microsoft.Maui.Graphics;
using System.Text.Json.Serialization;

namespace Coffers.Models;

public enum Flow { Out, In }

public class Transaction
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..10];
    public string Date { get; set; } = DateTime.Today.ToString("yyyy-MM-dd");
    public Flow Type { get; set; } = Flow.Out;
    public decimal Amount { get; set; }
    public string Category { get; set; } = "food";
    public string Note { get; set; } = "";

    [JsonIgnore]
    public DateTime When => DateTime.ParseExact(Date, "yyyy-MM-dd", CultureInfo.InvariantCulture);

    [JsonIgnore]
    public decimal Signed => Type == Flow.In ? Amount : -Amount;
}

public class Goal
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string Name { get; set; } = "";
    public decimal Target { get; set; }
    public decimal Saved { get; set; }
}

public class AppSettings
{
    public string Currency { get; set; } = "CZK";
    public decimal Opening { get; set; } = 90000m;
}

/// <summary>A monthly ceiling for one category. No budget set means no ceiling.</summary>
public class Budget
{
    public string Category { get; set; } = "";
    public decimal Monthly { get; set; }
}

/// <summary>
/// Rent, subscriptions, the gym. Posted automatically once its day of the month
/// arrives, so the ledger stays honest without you remembering.
/// </summary>
public class Recurring
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string Name { get; set; } = "";
    public decimal Amount { get; set; }
    public string Category { get; set; } = "home";
    public Flow Type { get; set; } = Flow.Out;
    public int DayOfMonth { get; set; } = 1;

    /// <summary>Month key (yyyy-MM) this last posted in, so it can't post twice.</summary>
    public string LastPosted { get; set; } = "";
}

public class Reminder
{
    public bool Enabled { get; set; }
    public int Hour { get; set; } = 20;
    public int Minute { get; set; }

    public string Text => $"{Hour:00}:{Minute:00}";
}

public class Book
{
    public List<Transaction> Transactions { get; set; } = new();
    public List<string> QuietDays { get; set; } = new();
    public List<Goal> Goals { get; set; } = new()
    {
        new Goal { Id = "g1", Name = "Move out",           Target = 120000m },
        new Goal { Id = "g2", Name = "Chug It marketing",  Target = 40000m  },
    };
    public AppSettings Settings { get; set; } = new();
    public List<Budget> Budgets { get; set; } = new();
    public List<Recurring> Recurring { get; set; } = new();
    public Reminder Reminder { get; set; } = new();
}

/// <summary>A spending or income bucket. Colour is the only hue in the app, so it carries meaning.</summary>
public record Category(string Id, string Label, string Hex, Flow Direction);

public static class Categories
{
    public static readonly Category[] Outgoing =
    {
        new("food",      "Food & drink",  "#D07B3F", Flow.Out),
        new("groceries", "Groceries",     "#4F8F5C", Flow.Out),
        new("home",      "Rent & bills",  "#6C63A6", Flow.Out),
        new("transport", "Transport",     "#3D7FA0", Flow.Out),
        new("out",       "Going out",     "#B5478A", Flow.Out),
        new("subs",      "Subscriptions", "#A8842B", Flow.Out),
        new("tech",      "Games & tech",  "#4A9490", Flow.Out),
        new("health",    "Health",        "#B8443C", Flow.Out),
        new("chugit",    "Chug It",       "#C77E23", Flow.Out),
        new("other",     "Other",         "#7C8A84", Flow.Out),
    };

    public static readonly Category[] Incoming =
    {
        new("salary",    "Salary",        "#2E8B57", Flow.In),
        new("freelance", "Freelance",     "#4A9490", Flow.In),
        new("gamerev",   "Game revenue",  "#C77E23", Flow.In),
        new("gift",      "Gift",          "#B5478A", Flow.In),
        new("inother",   "Other",         "#7C8A84", Flow.In),
    };

    public static IEnumerable<Category> For(Flow flow) => flow == Flow.In ? Incoming : Outgoing;

    public static Category Find(string id) =>
        Outgoing.Concat(Incoming).FirstOrDefault(c => c.Id == id)
        ?? new Category(id, id, "#7C8A84", Flow.Out);

    public static Color ColorOf(string id) => Color.FromArgb(Find(id).Hex);
}

public static class Money
{
    private static readonly Dictionary<string, string> Symbols = new()
    {
        ["CZK"] = "Kč", ["EUR"] = "€", ["USD"] = "$", ["GBP"] = "£", ["PLN"] = "zł",
    };

    public static readonly string[] Codes = { "CZK", "EUR", "USD", "GBP", "PLN" };

    public static string Symbol(string code) => Symbols.TryGetValue(code, out var s) ? s : code;

    /// <summary>Formatted without decimals — nobody budgets to the haler.</summary>
    public static string Format(decimal value, string code, bool showDecimals = false)
    {
        var nfi = (NumberFormatInfo)CultureInfo.InvariantCulture.NumberFormat.Clone();
        nfi.NumberGroupSeparator = " ";
        nfi.NumberDecimalSeparator = ".";
        var body = value.ToString(showDecimals ? "N2" : "N0", nfi);
        var sym = Symbol(code);
        return sym is "$" or "£" or "€" ? $"{sym}{body}" : $"{body} {sym}";
    }
}
