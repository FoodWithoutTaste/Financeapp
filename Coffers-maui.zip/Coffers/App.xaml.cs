using Coffers.Views;

namespace Coffers;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // The design is a light one. Don't let the system flip it.
        UserAppTheme = AppTheme.Light;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var nav = new NavigationPage(new MainPage())
        {
            BarBackgroundColor = Color.FromArgb("#F7F8F6"),
            BarTextColor = Color.FromArgb("#151A17"),
        };
        NavigationPage.SetHasNavigationBar(nav.RootPage, false);
        return new Window(nav);
    }
}
