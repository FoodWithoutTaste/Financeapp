using Coffers.Views;

namespace Coffers;

public partial class App : Application
{
    /// <summary>
    /// Set by MainActivity when the app is opened from the widget's record button.
    /// MainPage picks it up once the ledger has loaded, then clears it.
    /// </summary>
    public static string? PendingAction { get; set; }

    public App()
    {
        InitializeComponent();

        // The design is a light one. Don't let the system flip it.
        UserAppTheme = AppTheme.Light;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var main = new MainPage();
        NavigationPage.SetHasNavigationBar(main, false);

        var nav = new NavigationPage(main)
        {
            BarBackgroundColor = Color.FromArgb("#F7F8F6"),
            BarTextColor = Color.FromArgb("#151A17"),
        };

        return new Window(nav);
    }
}
