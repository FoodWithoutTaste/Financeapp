using Coffers.Views;

namespace Coffers;

public partial class App : Application
{
    /// <summary>
    /// Set by MainActivity when the app is opened from the widget's record button.
    /// MainPage picks it up once the ledger has loaded, then clears it.
    /// </summary>
    public static string? PendingAction { get; set; }

    private NavigationPage? _nav;

    public App()
    {
        InitializeComponent();

        // Whatever was chosen last time, before the first pixel is drawn.
        UserAppTheme = Theme.Requested;

        RequestedThemeChanged += (_, _) =>
        {
            PaintBar();
            Theme.PaintSystemChrome();
        };
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var main = new MainPage();
        NavigationPage.SetHasNavigationBar(main, false);

        _nav = new NavigationPage(main);
        PaintBar();

        return new Window(_nav);
    }

    private void PaintBar()
    {
        if (_nav is null) return;

        try
        {
            _nav.BarBackgroundColor = Theme.Paper;
            _nav.BarTextColor = Theme.Ink;
        }
        catch
        {
        }
    }
}
