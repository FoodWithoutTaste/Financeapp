using Coffers.Views;

namespace Coffers;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // The design is a light one. Don't let the system flip it.
        UserAppTheme = AppTheme.Light;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var main = new MainPage();
        NavigationPage.SetHasNavigationBar(main, false);

        var nav = new NavigationPage(main)
        {
            BarBackgroundColor = Color.FromArgb("#F7F8F6"),
            BarTextColor = Color.FromArgb("#151A17"),
        };

        return new Window(nav);
    }
}
