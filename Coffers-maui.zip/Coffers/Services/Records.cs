using Coffers.Models;

namespace Coffers.Services;

/// <summary>
/// Personal bests. Every record here is yours — you're chasing your own ghost,
/// never a stranger's average.
///
/// The important rule: a record only counts on days the ledger was actually kept.
/// A week you didn't open the app isn't a cheap week, it's a blank one. Otherwise
/// the fastest way to a new record would be to stop being honest, which is exactly
/// the behaviour a board like this must never reward.
/// </summary>
public static class Records
{
    public record Best(string Title, string Value, string When, string Chase, bool IsLive);

    private const string Iso = "yyyy-MM-dd";

    private static DateTime WeekStart(DateTime d) => d.AddDays(-(((int)d.DayOfWeek + 6) % 7));

    private static bool TryDate(string s, out DateTime d) =>
        DateTime.TryParseExact(s, Iso, System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out d);

    public static List<Best> For(Book book)
    {
        var cur = book.Settings.Currency;
        var today = DateTime.Today;
        var best = new List<Best>();

        // A day counts as kept if something was written down, or you marked it quiet.
        var kept = new HashSet<DateTime>();
        var spent = new Dictionary<DateTime, decimal>();
        var earned = new Dictionary<DateTime, decimal>();

        foreach (var t in book.Transactions)
        {
            if (!TryDate(t.Date, out var d)) continue;
            kept.Add(d);
            if (t.Type == Flow.Out) spent[d] = spent.GetValueOrDefault(d) + t.Amount;
            else earned[d] = earned.GetValueOrDefault(d) + t.Amount;
        }

        foreach (var q in book.QuietDays)
            if (TryDate(q, out var d)) kept.Add(d);

        if (kept.Count == 0) return best;

        // ---------- the cheapest week you've actually kept ----------
        var weeks = kept
            .GroupBy(WeekStart)
            .Where(g => g.Key.AddDays(6) < today)          // finished weeks only
            .Where(g => g.Count() >= 4)                     // and genuinely recorded
            .Select(g => new
            {
                Start = g.Key,
                Total = g.Sum(d => spent.GetValueOrDefault(d)),
            })
            .OrderBy(w => w.Total)
            .ToList();

        var thisWeek = WeekStart(today);
        var soFar = kept.Where(d => d >= thisWeek).Sum(d => spent.GetValueOrDefault(d));

        if (weeks.Count > 0)
        {
            var w = weeks[0];
            var beating = soFar < w.Total;
            best.Add(new Best(
                "Cheapest week",
                Money.Format(w.Total, cur),
                $"week of {w.Start:d MMM yyyy}",
                beating
                    ? $"This week: {Money.Format(soFar, cur)} — under the record"
                    : $"This week so far: {Money.Format(soFar, cur)}",
                beating));
        }

        // ---------- longest run of nights kept ----------
        var ordered = kept.OrderBy(d => d).ToList();
        var longest = 1;
        var runStart = ordered[0];
        var bestStart = ordered[0];
        var bestEnd = ordered[0];
        var run = 1;

        for (var i = 1; i < ordered.Count; i++)
        {
            if (ordered[i] == ordered[i - 1].AddDays(1))
            {
                run++;
            }
            else
            {
                run = 1;
                runStart = ordered[i];
            }

            if (run > longest)
            {
                longest = run;
                bestStart = runStart;
                bestEnd = ordered[i];
            }
        }

        // The run you're on right now, counting back from today or yesterday.
        var anchor = kept.Contains(today) ? today
                   : kept.Contains(today.AddDays(-1)) ? today.AddDays(-1)
                   : DateTime.MinValue;

        var current = 0;
        if (anchor != DateTime.MinValue)
        {
            var walk = anchor;
            while (kept.Contains(walk)) { current++; walk = walk.AddDays(-1); }
        }

        best.Add(new Best(
            "Longest run kept",
            longest == 1 ? "1 night" : $"{longest} nights",
            $"{bestStart:d MMM} – {bestEnd:d MMM yyyy}",
            current == 0 ? "Not on a run — record tonight to start one"
                         : $"On {current} now",
            current >= longest && current > 1));

        // ---------- best month ----------
        var months = kept
            .GroupBy(d => new DateTime(d.Year, d.Month, 1))
            .Select(g => new
            {
                Month = g.Key,
                Net = g.Sum(d => earned.GetValueOrDefault(d)) - g.Sum(d => spent.GetValueOrDefault(d)),
            })
            .Where(m => m.Month < new DateTime(today.Year, today.Month, 1))
            .OrderByDescending(m => m.Net)
            .ToList();

        var thisMonthNet =
            kept.Where(d => d.Year == today.Year && d.Month == today.Month)
                .Sum(d => earned.GetValueOrDefault(d) - spent.GetValueOrDefault(d));

        if (months.Count > 0)
        {
            var m = months[0];
            best.Add(new Best(
                "Best month",
                Money.Format(m.Net, cur),
                m.Month.ToString("MMMM yyyy"),
                $"This month: {Money.Format(thisMonthNet, cur)}",
                thisMonthNet > m.Net));
        }

        // ---------- longest quiet run: kept days where nothing went out ----------
        var quietBest = 0;
        var quietRun = 0;
        var quietEnd = DateTime.MinValue;
        var quietBestEnd = DateTime.MinValue;

        for (var i = 0; i < ordered.Count; i++)
        {
            var d = ordered[i];
            var isQuiet = spent.GetValueOrDefault(d) == 0m;
            var contiguous = i > 0 && ordered[i] == ordered[i - 1].AddDays(1);

            quietRun = isQuiet ? (contiguous ? quietRun + 1 : 1) : 0;
            if (isQuiet) quietEnd = d;

            if (quietRun > quietBest) { quietBest = quietRun; quietBestEnd = quietEnd; }
        }

        if (quietBest > 0)
        {
            var live = spent.GetValueOrDefault(today) == 0m && kept.Contains(today);
            best.Add(new Best(
                "Longest spend-free run",
                quietBest == 1 ? "1 day" : $"{quietBest} days",
                $"ending {quietBestEnd:d MMM yyyy}",
                live ? "Today is spend-free so far" : "Today has spending on it",
                false));
        }

        // ---------- your kindest month of verdicts ----------
        var verdictMonths = book.Transactions
            .Where(t => t.Verdict is Judgement.Worth or Judgement.NotWorth)
            .Where(t => t.Date.Length >= 7)
            .GroupBy(t => t.Date[..7])
            .Where(g => g.Count() >= 5)
            .Select(g => new
            {
                Key = g.Key,
                Rate = (double)g.Count(t => t.Verdict == Judgement.Worth) / g.Count(),
                Worth = g.Count(t => t.Verdict == Judgement.Worth),
                Total = g.Count(),
            })
            .OrderByDescending(m => m.Rate)
            .ToList();

        if (verdictMonths.Count > 0)
        {
            var v = verdictMonths[0];
            var label = TryDate(v.Key + "-01", out var vd) ? vd.ToString("MMMM yyyy") : v.Key;
            best.Add(new Best(
                "Best worth-it month",
                $"{(int)Math.Round(v.Rate * 100)}%",
                $"{label} · {v.Worth} of {v.Total}",
                "Judged a week after the money left",
                false));
        }

        return best;
    }
}
