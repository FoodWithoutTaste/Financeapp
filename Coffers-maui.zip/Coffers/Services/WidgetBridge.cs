using Microsoft.Maui.Storage;

namespace Coffers.Services;

/// <summary>
/// The one-way channel to the home screen. The app writes two lines; the widget reads them.
/// Kept to plain text on purpose — see CoffersWidget for why.
/// </summary>
public static class WidgetBridge
{
    public static void Push(string balance, string runway)
    {
        try
        {
            var path = Path.Combine(FileSystem.AppDataDirectory, "widget.txt");
            File.WriteAllText(path, balance + "\n" + runway);
        }
        catch
        {
            return;
        }

#if ANDROID
        try
        {
            CoffersWidget.Refresh(Android.App.Application.Context);
        }
        catch
        {
        }
#endif
    }
}
