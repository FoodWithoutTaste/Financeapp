using Coffers.Models;

namespace Coffers.Services;

/// <summary>
/// Posts recurring payments once their day of the month has arrived.
/// Deliberately conservative: it never back-fills months you weren't using the app,
/// and it can't post the same charge twice.
/// </summary>
public static class Recurrence
{
    public static int PostDue(Book book)
    {
        var today = DateTime.Today;
        var monthKey = today.ToString("yyyy-MM");
        var posted = 0;

        foreach (var r in book.Recurring)
        {
            if (r.Amount <= 0) continue;
            if (r.LastPosted == monthKey) continue;

            var lastDay = DateTime.DaysInMonth(today.Year, today.Month);
            var day = Math.Clamp(r.DayOfMonth, 1, lastDay);
            if (today.Day < day) continue;

            book.Transactions.Add(new Transaction
            {
                Date = new DateTime(today.Year, today.Month, day).ToString("yyyy-MM-dd"),
                Type = r.Type,
                Amount = r.Amount,
                Category = r.Category,
                Note = string.IsNullOrWhiteSpace(r.Name) ? "Recurring" : r.Name,
            });

            r.LastPosted = monthKey;
            posted++;
        }

        return posted;
    }
}
