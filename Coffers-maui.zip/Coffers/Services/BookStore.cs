using Microsoft.Maui.Storage;
using Microsoft.Maui.ApplicationModel.DataTransfer;
using System.Text.Json;
using Coffers.Models;

namespace Coffers.Services;

/// <summary>
/// Reads and writes the book as JSON in the app's private data directory.
/// Writes go to a temp file first and only then replace the live file, so a crash
/// or a killed process can never leave a half-written book on disk. The previous
/// good copy is kept as .bak and is used automatically if the main file is corrupt.
/// </summary>
public class BookStore
{
    private readonly string _dir = FileSystem.AppDataDirectory;
    private readonly SemaphoreSlim _gate = new(1, 1);

    private string Main => Path.Combine(_dir, "coffers.json");
    private string Backup => Path.Combine(_dir, "coffers.bak.json");
    private string Temp => Path.Combine(_dir, "coffers.tmp.json");

    private static readonly JsonSerializerOptions Json = new()
    {
        WriteIndented = false,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public string LastError { get; private set; } = "";

    public async Task<Book> LoadAsync()
    {
        LastError = "";
        await _gate.WaitAsync();
        try
        {
            var book = TryRead(Main);
            if (book is not null) return book;

            book = TryRead(Backup);
            if (book is not null)
            {
                LastError = "The main file was unreadable, so your last backup was restored.";
                return book;
            }

            return new Book();
        }
        finally { _gate.Release(); }
    }

    public async Task<bool> SaveAsync(Book book)
    {
        await _gate.WaitAsync();
        try
        {
            var payload = JsonSerializer.Serialize(book, Json);

            // Prove it round-trips before letting it near the live file.
            _ = JsonSerializer.Deserialize<Book>(payload, Json)
                ?? throw new InvalidOperationException("serialised book did not round-trip");

            await File.WriteAllTextAsync(Temp, payload);

            if (File.Exists(Main))
                File.Copy(Main, Backup, overwrite: true);

            File.Move(Temp, Main, overwrite: true);

            LastError = "";
            return true;
        }
        catch (Exception ex)
        {
            LastError = $"Couldn't save: {ex.Message}. Export a backup before closing the app.";
            return false;
        }
        finally { _gate.Release(); }
    }

    private static Book? TryRead(string path)
    {
        try
        {
            if (!File.Exists(path)) return null;
            var text = File.ReadAllText(path);
            if (string.IsNullOrWhiteSpace(text)) return null;
            var book = JsonSerializer.Deserialize<Book>(text, Json);
            if (book is null) return null;

            book.Transactions ??= new();
            book.QuietDays ??= new();
            book.Goals ??= new();
            book.Settings ??= new();
            book.Budgets ??= new();
            book.Recurring ??= new();
            book.Reminder ??= new();
            return book;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>CSV of every entry, oldest first. This is what you paste into a chat for review.</summary>
    public static string ToCsv(Book book)
    {
        var lines = new List<string> { "date,type,category,amount,note,worth_it" };
        foreach (var x in book.Transactions.OrderBy(t => t.Date))
        {
            var note = (x.Note ?? "").Replace("\"", "\"\"");
            var cat = Categories.Find(x.Category).Label;
            var verdict = x.Verdict switch
            {
                1 => "yes",
                -1 => "no",
                2 => "skipped",
                _ => "",
            };
            lines.Add($"{x.Date},{(x.Type == Flow.In ? "in" : "out")},{cat},{x.Amount},\"{note}\",{verdict}");
        }
        return string.Join("\n", lines);
    }

    public static string ToJson(Book book) => JsonSerializer.Serialize(book, Json);

    public static Book? FromJson(string text)
    {
        try
        {
            var book = JsonSerializer.Deserialize<Book>(text, Json);
            if (book?.Transactions is null) return null;
            book.QuietDays ??= new();
            book.Goals ??= new();
            book.Settings ??= new();
            book.Budgets ??= new();
            book.Recurring ??= new();
            book.Reminder ??= new();
            return book;
        }
        catch { return null; }
    }

    /// <summary>Writes a dated CSV to the cache folder and opens the Android share sheet.</summary>
    public async Task ShareCsvAsync(Book book)
    {
        var path = Path.Combine(FileSystem.CacheDirectory, $"coffers-{DateTime.Today:yyyy-MM-dd}.csv");
        await File.WriteAllTextAsync(path, ToCsv(book));
        await Share.Default.RequestAsync(new ShareFileRequest
        {
            Title = "Coffers export",
            File = new ShareFile(path),
        });
    }
}
