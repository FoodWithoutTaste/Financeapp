using Coffers.Models;

namespace Coffers.Services;

public enum Tone { Flat, Warn, Good }

public record Note(Tone Tone, string Text);

/// <summary>
/// Reads the month and says something true about it. Deliberately conservative:
/// it only speaks when there is enough data to mean anything.
/// </summary>
public static class Insights
{
    public static List<Note> For(Book book, string monthKey)
    {
        var notes = new List<Note>();
        var cur = book.Settings.Currency;

        var month = book.Transactions.Where(t => t.Date.StartsWith(monthKey)).ToList();
        if (month.Count < 3) return notes;

        var spent = month.Where(t => t.Type == Flow.Out).ToList();
        var totalOut = spent.Sum(t => t.Amount);
        var totalIn = month.Where(t => t.Type == Flow.In).Sum(t => t.Amount);

        var byCat = spent
            .GroupBy(t => t.Category)
            .Select(g => new { Cat = g.Key, Sum = g.Sum(x => x.Amount), Count = g.Count() })
            .OrderByDescending(x => x.Sum)
            .ToList();

        // 1. What dominates.
        if (byCat.Count > 0 && totalOut > 0)
        {
            var top = byCat[0];
            var share = (int)Math.Round(top.Sum / totalOut * 100);
            if (share >= 25)
                notes.Add(new Note(Tone.Flat,
                    $"{Categories.Find(top.Cat).Label} is {share}% of everything you spent — {Money.Format(top.Sum, cur)}."));
        }

        // 2. What's drifting up against its own recent average.
        foreach (var c in byCat)
        {
            var history = new List<decimal>();
            for (var i = 1; i <= 3; i++)
            {
                var mk = ShiftMonth(monthKey, -i);
                var sum = book.Transactions
                    .Where(t => t.Type == Flow.Out && t.Category == c.Cat && t.Date.StartsWith(mk))
                    .Sum(t => t.Amount);
                history.Add(sum);
            }
            if (history.Count(h => h > 0) < 2) continue;

            var avg = history.Average();
            if (avg > 0 && c.Sum > avg * 1.35m)
            {
                var pct = (int)Math.Round((c.Sum - avg) / avg * 100);
                notes.Add(new Note(Tone.Warn,
                    $"{Categories.Find(c.Cat).Label} is up {pct}% on your recent average."));
            }
        }

        // 3. Death by a thousand cuts.
        var nibble = byCat.Where(c => c.Count >= 8).OrderByDescending(c => c.Sum).FirstOrDefault();
        if (nibble is not null)
            notes.Add(new Note(Tone.Flat,
                $"{nibble.Count} separate {Categories.Find(nibble.Cat).Label.ToLowerInvariant()} entries add up to {Money.Format(nibble.Sum, cur)}."));

        // 4. The quiet annual cost of subscriptions.
        var subs = byCat.FirstOrDefault(c => c.Cat == "subs");
        if (subs is not null)
            notes.Add(new Note(Tone.Flat,
                $"Subscriptions cost {Money.Format(subs.Sum * 12, cur)} a year at this rate."));

        // 5. The bottom line.
        if (totalIn > 0)
        {
            var kept = (int)Math.Round((totalIn - totalOut) / totalIn * 100);
            notes.Add(kept < 0
                ? new Note(Tone.Warn, $"You spent {Money.Format(totalOut - totalIn, cur)} more than you earned.")
                : new Note(kept >= 20 ? Tone.Good : Tone.Flat, $"You kept {kept}% of what came in."));
        }

        return notes.Take(4).ToList();
    }

    public static string ShiftMonth(string monthKey, int by)
    {
        var year = int.Parse(monthKey[..4]);
        var month = int.Parse(monthKey[5..7]);
        var d = new DateTime(year, month, 1).AddMonths(by);
        return d.ToString("yyyy-MM");
    }

    public static string PrettyMonth(string monthKey)
    {
        var year = int.Parse(monthKey[..4]);
        var month = int.Parse(monthKey[5..7]);
        return $"{new DateTime(year, month, 1):MMMM} {year}";
    }
}
