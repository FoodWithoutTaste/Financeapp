using Coffers.Models;
using Microsoft.Maui.Graphics;

namespace Coffers.Services;

/// <summary>
/// The worth-it tap. A week after the money left, you say yes or no.
/// It is deliberately retrospective — asking at the till just gets you a yes.
/// </summary>
public static class Judgement
{
    public const int Unjudged = 0;
    public const int Worth = 1;
    public const int NotWorth = -1;
    public const int Skipped = 2;

    /// <summary>The oldest payment still waiting on a verdict, or null if the queue is clear.</summary>
    public static Transaction? Next(Book book)
    {
        if (!book.Settings.WorthIt) return null;

        var floor = book.Settings.WorthItFloor;
        var delay = Math.Clamp(book.Settings.WorthItDelay, 0, 90);
        var cutoff = DateTime.Today.AddDays(-delay).ToString("yyyy-MM-dd");

        return book.Transactions
            .Where(t => t.Type == Flow.Out
                     && t.Verdict == Unjudged
                     && t.Amount >= floor
                     && string.CompareOrdinal(t.Date, cutoff) <= 0)
            .OrderBy(t => t.Date, StringComparer.Ordinal)
            .FirstOrDefault();
    }

    public static int Waiting(Book book)
    {
        if (!book.Settings.WorthIt) return 0;

        var floor = book.Settings.WorthItFloor;
        var delay = Math.Clamp(book.Settings.WorthItDelay, 0, 90);
        var cutoff = DateTime.Today.AddDays(-delay).ToString("yyyy-MM-dd");

        return book.Transactions.Count(t => t.Type == Flow.Out
                                         && t.Verdict == Unjudged
                                         && t.Amount >= floor
                                         && string.CompareOrdinal(t.Date, cutoff) <= 0);
    }

    /// <summary>How a single category has fared under your own judgement.</summary>
    public record Verdicts(string Label, Color Hue, int Worth, int Total, decimal Regret)
    {
        public double Rate => Total == 0 ? 0 : (double)Worth / Total;
    }

    public static List<Verdicts> ByCategory(Book book)
    {
        var judged = book.Transactions
            .Where(t => t.Type == Flow.Out && t.Verdict is Worth or NotWorth)
            .ToList();

        return judged
            .GroupBy(t => t.Category)
            .Select(g =>
            {
                var cat = Categories.Find(g.Key);
                return new Verdicts(
                    cat.Label,
                    Theme.Tint(cat.Hex),
                    g.Count(t => t.Verdict == Worth),
                    g.Count(),
                    g.Where(t => t.Verdict == NotWorth).Sum(t => t.Amount));
            })
            .OrderBy(v => v.Rate)
            .ThenByDescending(v => v.Total)
            .ToList();
    }

    /// <summary>Everything you spent on things you afterwards said weren't worth it.</summary>
    public static decimal Regret(Book book) =>
        book.Transactions.Where(t => t.Verdict == NotWorth).Sum(t => t.Amount);

    public static (int Worth, int Total) Tally(Book book)
    {
        var judged = book.Transactions.Where(t => t.Verdict is Worth or NotWorth).ToList();
        return (judged.Count(t => t.Verdict == Worth), judged.Count);
    }
}
