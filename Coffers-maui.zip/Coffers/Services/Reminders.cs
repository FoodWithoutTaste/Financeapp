namespace Coffers.Services;

#if ANDROID
using Android.App;
using Android.Content;
using Android.OS;

/// <summary>
/// Fires the nightly nudge. Everything here is wrapped: a reminder failing to
/// appear is a small annoyance, a reminder crashing the app is not acceptable.
/// </summary>
[BroadcastReceiver(Enabled = true, Exported = false)]
public class ReminderReceiver : BroadcastReceiver
{
    public const string ChannelId = "coffers.daily";

    public override void OnReceive(Context? context, Intent? intent)
    {
        if (context is null) return;

        try
        {
            var manager = (NotificationManager?)context.GetSystemService(Context.NotificationService);
            if (manager is null) return;

            manager.CreateNotificationChannel(
                new NotificationChannel(ChannelId, "Daily reminder", NotificationImportance.Default)
                {
                    Description = "A nudge to write down what you spent.",
                });

            var launch = context.PackageManager?.GetLaunchIntentForPackage(context.PackageName!);
            var pending = PendingIntent.GetActivity(
                context, 0, launch,
                PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);

            var note = new Notification.Builder(context, ChannelId)
                .SetContentTitle("Coffers")
                .SetContentText("What did you spend today?")
                .SetSmallIcon(Android.Resource.Drawable.IcMenuAgenda)
                .SetAutoCancel(true)
                .SetContentIntent(pending)
                .Build();

            manager.Notify(4021, note);
        }
        catch
        {
            // Swallowed on purpose.
        }
    }
}
#endif

public static class Reminders
{
    /// <summary>Asks for notification permission. Returns false if the person says no.</summary>
    public static async Task<bool> RequestPermissionAsync()
    {
        try
        {
            var status = await Permissions.CheckStatusAsync<Permissions.PostNotifications>();
            if (status != PermissionStatus.Granted)
                status = await Permissions.RequestAsync<Permissions.PostNotifications>();
            return status == PermissionStatus.Granted;
        }
        catch
        {
            return false;
        }
    }

    public static void Schedule(int hour, int minute)
    {
#if ANDROID
        try
        {
            var context = Android.App.Application.Context;
            var alarm = (AlarmManager?)context.GetSystemService(Context.AlarmService);
            if (alarm is null) return;

            var now = DateTime.Now;
            var target = new DateTime(now.Year, now.Month, now.Day, hour, minute, 0, DateTimeKind.Local);
            if (target <= now) target = target.AddDays(1);
            var millis = (long)(target.ToUniversalTime() - DateTime.UnixEpoch).TotalMilliseconds;

            // Inexact on purpose: a daily nudge doesn't need to hit the second, and
            // exact alarms would mean asking for a permission Android now guards closely.
            alarm.SetRepeating(AlarmType.RtcWakeup, millis, AlarmManager.IntervalDay, Pending(context));
        }
        catch
        {
        }
#endif
    }

    public static void Cancel()
    {
#if ANDROID
        try
        {
            var context = Android.App.Application.Context;
            var alarm = (AlarmManager?)context.GetSystemService(Context.AlarmService);
            alarm?.Cancel(Pending(context));
        }
        catch
        {
        }
#endif
    }

#if ANDROID
    private static PendingIntent Pending(Context context) =>
        PendingIntent.GetBroadcast(
            context, 4021,
            new Intent(context, typeof(ReminderReceiver)),
            PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable)!;
#endif
}
