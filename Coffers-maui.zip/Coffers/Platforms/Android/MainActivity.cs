using Android.App;
using Android.Content.PM;
using Android.OS;

namespace Coffers;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ScreenOrientation = ScreenOrientation.Portrait,
    ConfigurationChanges = ConfigChanges.ScreenSize
                         | ConfigChanges.Orientation
                         | ConfigChanges.UiMode
                         | ConfigChanges.ScreenLayout
                         | ConfigChanges.SmallestScreenSize
                         | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Match the paper background so there's no dark flash on launch.
        Window?.SetStatusBarColor(Android.Graphics.Color.ParseColor("#F7F8F6"));
        if (Build.VERSION.SdkInt >= BuildVersionCodes.M && Window?.DecorView is { } decor)
            decor.SystemUiVisibility = (Android.Views.StatusBarVisibility)
                Android.Views.SystemUiFlags.LightStatusBar;
    }
}
