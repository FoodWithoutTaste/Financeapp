using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;

namespace Coffers;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ScreenOrientation = ScreenOrientation.Portrait,
    ConfigurationChanges = ConfigChanges.ScreenSize
                         | ConfigChanges.Orientation
                         | ConfigChanges.UiMode
                         | ConfigChanges.ScreenLayout
                         | ConfigChanges.SmallestScreenSize
                         | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        Consume(Intent);

        // Match the paper background, with dark icons so they stay readable.
        try
        {
            Window?.SetStatusBarColor(Android.Graphics.Color.ParseColor("#F7F8F6"));

            if (OperatingSystem.IsAndroidVersionAtLeast(30))
            {
                // WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS — dark icons on a light bar.
                const int lightStatusBars = 8;
                Window?.InsetsController?.SetSystemBarsAppearance(lightStatusBars, lightStatusBars);
            }
        }
        catch
        {
            // Cosmetic only. Never let this stop the app opening.
        }
    }

    protected override void OnNewIntent(Intent? intent)
    {
        base.OnNewIntent(intent);
        Consume(intent);
    }

    /// <summary>
    /// Reads the widget's request off the launch intent and hands it to the app,
    /// then strips it so a rotation or a return from background can't fire it twice.
    /// </summary>
    private static void Consume(Intent? intent)
    {
        try
        {
            if (intent?.GetStringExtra(CoffersWidget.ExtraAction) != CoffersWidget.ActionRecord)
                return;

            Coffers.App.PendingAction = CoffersWidget.ActionRecord;
            intent.RemoveExtra(CoffersWidget.ExtraAction);
        }
        catch
        {
        }
    }
}
