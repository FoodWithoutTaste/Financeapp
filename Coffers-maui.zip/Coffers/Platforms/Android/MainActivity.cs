using Android.App;
using Android.Content.PM;
using Android.OS;

namespace Coffers;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ScreenOrientation = ScreenOrientation.Portrait,
    ConfigurationChanges = ConfigChanges.ScreenSize
                         | ConfigChanges.Orientation
                         | ConfigChanges.UiMode
                         | ConfigChanges.ScreenLayout
                         | ConfigChanges.SmallestScreenSize
                         | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Match the paper background, with dark icons so they stay readable.
        try
        {
            Window?.SetStatusBarColor(Android.Graphics.Color.ParseColor("#F7F8F6"));

            if (OperatingSystem.IsAndroidVersionAtLeast(30))
            {
                // WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS — dark icons on a light bar.
                const int lightStatusBars = 8;
                Window?.InsetsController?.SetSystemBarsAppearance(lightStatusBars, lightStatusBars);
            }
        }
        catch
        {
            // Cosmetic only. Never let this stop the app opening.
        }
    }
}
