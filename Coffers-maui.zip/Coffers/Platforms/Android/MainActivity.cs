using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;

namespace Coffers;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ScreenOrientation = ScreenOrientation.Portrait,
    ConfigurationChanges = ConfigChanges.ScreenSize
                         | ConfigChanges.Orientation
                         | ConfigChanges.UiMode
                         | ConfigChanges.ScreenLayout
                         | ConfigChanges.SmallestScreenSize
                         | ConfigChanges.Density)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        Consume(Intent);

        // Match the page behind them — light or dark, whichever is in force.
        try
        {
            var dark = Coffers.Theme.IsDark;
            var shade = Android.Graphics.Color.ParseColor(dark ? "#141613" : "#F7F8F6");

            Window?.SetStatusBarColor(shade);
            Window?.SetNavigationBarColor(shade);

            if (OperatingSystem.IsAndroidVersionAtLeast(30))
            {
                // APPEARANCE_LIGHT_STATUS_BARS | APPEARANCE_LIGHT_NAVIGATION_BARS.
                const int lightBars = 8 | 16;
                Window?.InsetsController?.SetSystemBarsAppearance(dark ? 0 : lightBars, lightBars);
            }
        }
        catch
        {
            // Cosmetic only. Never let this stop the app opening.
        }
    }

    protected override void OnNewIntent(Intent? intent)
    {
        base.OnNewIntent(intent);
        Consume(intent);
    }

    /// <summary>
    /// Reads the widget's request off the launch intent and hands it to the app,
    /// then strips it so a rotation or a return from background can't fire it twice.
    /// </summary>
    private static void Consume(Intent? intent)
    {
        try
        {
            if (intent?.GetStringExtra(CoffersWidget.ExtraAction) != CoffersWidget.ActionRecord)
                return;

            Coffers.App.PendingAction = CoffersWidget.ActionRecord;
            intent.RemoveExtra(CoffersWidget.ExtraAction);
        }
        catch
        {
        }
    }
}
