using Android.App;
using Android.Runtime;

namespace Coffers;

/// <summary>
/// Android's entry point. Without this class MAUI never starts and the activity
/// opens onto an empty window.
/// </summary>
[Application(AllowBackup = true)]
public class MainApplication : MauiApplication
{
    public MainApplication(IntPtr handle, JniHandleOwnership ownership)
        : base(handle, ownership)
    {
    }

    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
