using Android.App;
using Android.Appwidget;
using Android.Content;
using Android.Widget;

namespace Coffers;

/// <summary>
/// The home screen widget.
///
/// Two deliberate decisions here. First, it knows nothing about the ledger format —
/// the app writes two plain lines into widget.txt on every save and this only reads
/// them back, so a broadcast receiver waking with the app long dead can't trip over
/// something it fails to deserialise. Second, resource ids are looked up by name at
/// runtime rather than through the generated Resource class. That costs a deprecated
/// call and buys a much better failure mode: if anything about the resource pipeline
/// misbehaves, the widget quietly does nothing instead of taking the build down.
/// </summary>
[BroadcastReceiver(Label = "Coffers", Exported = true)]
[IntentFilter(new[] { "android.appwidget.action.APPWIDGET_UPDATE" })]
[MetaData("android.appwidget.provider", Resource = "@xml/coffers_widget_info")]
public class CoffersWidget : AppWidgetProvider
{
    public const string ExtraAction = "coffers.action";
    public const string ActionRecord = "record";
    public const string StateFile = "widget.txt";

    public override void OnUpdate(Context? context, AppWidgetManager? manager, int[]? ids)
    {
        if (context is null || manager is null || ids is null) return;

        try
        {
            var views = Build(context);
            if (views is null) return;
            foreach (var id in ids) manager.UpdateAppWidget(id, views);
        }
        catch
        {
            // A widget that can't draw must never take the app with it.
        }
    }

    /// <summary>Redraws every placed widget. Called by the app after each save.</summary>
    public static void Refresh(Context? context)
    {
        if (context is null) return;

        try
        {
            var manager = AppWidgetManager.GetInstance(context);
            if (manager is null) return;

            var component = new ComponentName(context, Java.Lang.Class.FromType(typeof(CoffersWidget)));
            var ids = manager.GetAppWidgetIds(component);
            if (ids is null || ids.Length == 0) return;

            var views = Build(context);
            if (views is null) return;

            foreach (var id in ids) manager.UpdateAppWidget(id, views);
        }
        catch
        {
        }
    }

    private static int Id(Context context, string name, string type)
    {
        try { return context.Resources?.GetIdentifier(name, type, context.PackageName) ?? 0; }
        catch { return 0; }
    }

    private static RemoteViews? Build(Context context)
    {
        var layout = Id(context, "coffers_widget", "layout");
        if (layout == 0) return null;

        var views = new RemoteViews(context.PackageName, layout);

        var balance = "—";
        var runway = "Open Coffers to begin";

        try
        {
            var path = System.IO.Path.Combine(context.FilesDir!.AbsolutePath, StateFile);
            if (System.IO.File.Exists(path))
            {
                var lines = System.IO.File.ReadAllLines(path);
                if (lines.Length > 0 && lines[0].Length > 0) balance = lines[0];
                if (lines.Length > 1 && lines[1].Length > 0) runway = lines[1];
            }
        }
        catch
        {
        }

        var balanceId = Id(context, "widget_balance", "id");
        var runwayId = Id(context, "widget_runway", "id");
        var rootId = Id(context, "widget_root", "id");
        var recordId = Id(context, "widget_record", "id");

        if (balanceId != 0) views.SetTextViewText(balanceId, balance);
        if (runwayId != 0) views.SetTextViewText(runwayId, runway);

        if (rootId != 0) views.SetOnClickPendingIntent(rootId, Launch(context, null, 8801));
        if (recordId != 0) views.SetOnClickPendingIntent(recordId, Launch(context, ActionRecord, 8802));

        return views;
    }

    private static PendingIntent? Launch(Context context, string? action, int requestCode)
    {
        var intent = new Intent(context, typeof(MainActivity));
        intent.SetFlags(ActivityFlags.NewTask | ActivityFlags.SingleTop);
        if (action is not null) intent.PutExtra(ExtraAction, action);

        return PendingIntent.GetActivity(
            context, requestCode, intent,
            PendingIntentFlags.UpdateCurrent | PendingIntentFlags.Immutable);
    }
}
