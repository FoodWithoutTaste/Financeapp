using Microsoft.Extensions.Logging;

namespace Coffers;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        // Deliberately no custom fonts: the app uses the system sans, which keeps
        // the project text-only and means there are no binary assets to ship.
        builder.UseMauiApp<App>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}
