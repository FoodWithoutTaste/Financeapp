using Microsoft.Maui.Graphics;
using Coffers.Models;
using HAlign = Microsoft.Maui.Graphics.HorizontalAlignment;
using VAlign = Microsoft.Maui.Graphics.VerticalAlignment;

namespace Coffers.Drawables;

/// <summary>
/// What the hand-drawn charts paint with. Properties, not constants — they have to
/// answer differently once the page turns dark.
/// </summary>
public static class Palette
{
    public static Color Ink   => Theme.Ink;
    public static Color Muted => Theme.Muted;
    public static Color Rule  => Theme.Rule;
    public static Color Card  => Theme.Card;
    public static Color In    => Theme.MoneyIn;
    public static Color Out   => Theme.MoneyOut;
}

public record CatSlice(string Label, decimal Value, Color Color);

/// <summary>Horizontal bars, one per category, labels inline. Reads top to bottom, biggest first.</summary>
public class CategoryBarChart : IDrawable
{
    public List<CatSlice> Slices { get; set; } = new();
    public Func<decimal, string> Format { get; set; } = v => v.ToString("N0");

    public const float RowHeight = 40f;

    public void Draw(ICanvas canvas, RectF rect)
    {
        canvas.Antialias = true;
        if (Slices.Count == 0) return;

        var max = (float)Slices.Max(s => s.Value);
        if (max <= 0) return;

        const float labelW = 112f;
        const float gap = 10f;
        const float barH = 12f;
        var trackW = rect.Width - labelW - gap - 4f;

        for (var i = 0; i < Slices.Count; i++)
        {
            var s = Slices[i];
            var top = rect.Y + i * RowHeight;
            var mid = top + RowHeight / 2f;

            canvas.FontColor = Palette.Ink;
            canvas.FontSize = 12.5f;
            canvas.DrawString(s.Label, rect.X, mid - 14f, labelW, 16f,
                HAlign.Left, VAlign.Center);

            canvas.FontColor = Palette.Muted;
            canvas.FontSize = 11f;
            canvas.DrawString(Format(s.Value), rect.X, mid + 1f, labelW, 14f,
                HAlign.Left, VAlign.Center);

            var x = rect.X + labelW + gap;

            canvas.FillColor = Palette.Rule;
            canvas.FillRoundedRectangle(x, mid - barH / 2f, trackW, barH, barH / 2f);

            var w = Math.Max(barH, trackW * ((float)s.Value / max));
            canvas.FillColor = s.Color;
            canvas.FillRoundedRectangle(x, mid - barH / 2f, w, barH, barH / 2f);
        }
    }
}

/// <summary>Cumulative spend through the month, with last month behind it as a dashed line.</summary>
public class PaceChart : IDrawable
{
    public List<decimal> Current { get; set; } = new();
    public List<decimal> Previous { get; set; } = new();

    public void Draw(ICanvas canvas, RectF rect)
    {
        canvas.Antialias = true;
        if (Current.Count < 2) return;

        var padL = 8f; var padR = 8f; var padT = 12f; var padB = 20f;
        var w = rect.Width - padL - padR;
        var h = rect.Height - padT - padB;
        if (w <= 0 || h <= 0) return;

        var peak = (float)Math.Max(
            Current.Count > 0 ? Current.Max() : 0m,
            Previous.Count > 0 ? Previous.Max() : 0m);
        if (peak <= 0) peak = 1f;

        // horizontal guides
        canvas.StrokeColor = Palette.Rule;
        canvas.StrokeSize = 1f;
        for (var g = 0; g <= 3; g++)
        {
            var y = rect.Y + padT + h * g / 3f;
            canvas.DrawLine(rect.X + padL, y, rect.X + padL + w, y);
        }

        PointF At(IReadOnlyList<decimal> series, int i)
        {
            var x = rect.X + padL + w * i / Math.Max(1, series.Count - 1);
            var y = rect.Y + padT + h - h * ((float)series[i] / peak);
            return new PointF(x, y);
        }

        if (Previous.Count > 1)
        {
            var prev = new PathF();
            prev.MoveTo(At(Previous, 0));
            for (var i = 1; i < Previous.Count; i++) prev.LineTo(At(Previous, i));
            canvas.StrokeColor = Palette.Muted.WithAlpha(0.45f);
            canvas.StrokeSize = 1.5f;
            canvas.StrokeDashPattern = new float[] { 4, 4 };
            canvas.DrawPath(prev);
            canvas.StrokeDashPattern = null;
        }

        // filled area under this month
        var fill = new PathF();
        fill.MoveTo(new PointF(rect.X + padL, rect.Y + padT + h));
        for (var i = 0; i < Current.Count; i++) fill.LineTo(At(Current, i));
        fill.LineTo(new PointF(rect.X + padL + w, rect.Y + padT + h));
        fill.Close();
        canvas.FillColor = Palette.Ink.WithAlpha(0.07f);
        canvas.FillPath(fill);

        var line = new PathF();
        line.MoveTo(At(Current, 0));
        for (var i = 1; i < Current.Count; i++) line.LineTo(At(Current, i));
        canvas.StrokeColor = Palette.Ink;
        canvas.StrokeSize = 2f;
        canvas.StrokeLineJoin = LineJoin.Round;
        canvas.DrawPath(line);

        canvas.FontColor = Palette.Muted;
        canvas.FontSize = 10f;
        canvas.DrawString("day 1", rect.X + padL, rect.Bottom - 14f, 40f, 12f,
            HAlign.Left, VAlign.Center);
        canvas.DrawString($"day {Current.Count}", rect.X + padL + w - 40f, rect.Bottom - 14f, 40f, 12f,
            HAlign.Right, VAlign.Center);
    }
}

/// <summary>Month-end balance across the last year, so you can see the direction of travel.</summary>
public class BalanceChart : IDrawable
{
    public List<decimal> Values { get; set; } = new();
    public List<string> Labels { get; set; } = new();
    public Func<decimal, string> Format { get; set; } = v => v.ToString("N0");

    public void Draw(ICanvas canvas, RectF rect)
    {
        canvas.Antialias = true;
        if (Values.Count < 2) return;

        const float padL = 8f, padR = 8f, padT = 16f, padB = 22f;
        var w = rect.Width - padL - padR;
        var h = rect.Height - padT - padB;
        if (w <= 0 || h <= 0) return;

        var hi = (float)Values.Max();
        var lo = (float)Values.Min();
        if (Math.Abs(hi - lo) < 0.01f) { hi += 1f; lo -= 1f; }
        var span = hi - lo;
        var pad = span * 0.15f;
        hi += pad; lo -= pad; span = hi - lo;

        canvas.StrokeColor = Palette.Rule;
        canvas.StrokeSize = 1f;
        for (var g = 0; g <= 3; g++)
        {
            var y = rect.Y + padT + h * g / 3f;
            canvas.DrawLine(rect.X + padL, y, rect.X + padL + w, y);
        }

        PointF At(int i) => new(
            rect.X + padL + w * i / Math.Max(1, Values.Count - 1),
            rect.Y + padT + h - h * (((float)Values[i] - lo) / span));

        // zero line, if the balance ever crosses it
        if (lo < 0 && hi > 0)
        {
            var zeroY = rect.Y + padT + h - h * ((0f - lo) / span);
            canvas.StrokeColor = Palette.Out.WithAlpha(0.5f);
            canvas.StrokeDashPattern = new float[] { 3, 3 };
            canvas.DrawLine(rect.X + padL, zeroY, rect.X + padL + w, zeroY);
            canvas.StrokeDashPattern = null;
        }

        var fill = new PathF();
        fill.MoveTo(new PointF(rect.X + padL, rect.Y + padT + h));
        for (var i = 0; i < Values.Count; i++) fill.LineTo(At(i));
        fill.LineTo(new PointF(rect.X + padL + w, rect.Y + padT + h));
        fill.Close();
        canvas.FillColor = Palette.Ink.WithAlpha(0.06f);
        canvas.FillPath(fill);

        var line = new PathF();
        line.MoveTo(At(0));
        for (var i = 1; i < Values.Count; i++) line.LineTo(At(i));
        canvas.StrokeColor = Palette.Ink;
        canvas.StrokeSize = 2f;
        canvas.StrokeLineJoin = LineJoin.Round;
        canvas.DrawPath(line);

        var last = At(Values.Count - 1);
        canvas.FillColor = Palette.Ink;
        canvas.FillCircle(last.X, last.Y, 4f);

        canvas.FontColor = Palette.Muted;
        canvas.FontSize = 10f;
        if (Labels.Count == Values.Count)
        {
            canvas.DrawString(Labels[0], rect.X + padL, rect.Bottom - 14f, 46f, 12f,
                HAlign.Left, VAlign.Center);
            canvas.DrawString(Labels[^1], rect.X + padL + w - 46f, rect.Bottom - 14f, 46f, 12f,
                HAlign.Right, VAlign.Center);
        }
        canvas.DrawString(Format(Values.Max()), rect.X + padL, rect.Y, w, 13f,
            HAlign.Right, VAlign.Center);
    }
}

/// <summary>
/// A month laid out as a calendar, each day shaded by how much went out.
/// Patterns show up here that a bar chart hides — weekends, paydays, bad Fridays.
/// </summary>
public class DayHeatmap : IDrawable
{
    /// <summary>Spend per day, index 0 = the 1st.</summary>
    public List<decimal> Days { get; set; } = new();

    /// <summary>Weekday the 1st falls on, 0 = Monday.</summary>
    public int FirstWeekday { get; set; }

    public void Draw(ICanvas canvas, RectF rect)
    {
        canvas.Antialias = true;
        if (Days.Count == 0) return;

        var names = new[] { "M", "T", "W", "T", "F", "S", "S" };
        const float headH = 18f;
        var cell = Math.Min((rect.Width - 6 * 6f) / 7f, 40f);
        var gridW = cell * 7 + 6 * 6f;
        var left = rect.X + (rect.Width - gridW) / 2f;

        canvas.FontSize = 10f;
        canvas.FontColor = Palette.Muted;
        for (var i = 0; i < 7; i++)
        {
            canvas.DrawString(names[i], left + i * (cell + 6f), rect.Y, cell, headH,
                HAlign.Center, VAlign.Center);
        }

        var peak = (float)Math.Max(0.01m, Days.Max());

        for (var d = 0; d < Days.Count; d++)
        {
            var slot = FirstWeekday + d;
            var col = slot % 7;
            var row = slot / 7;

            var x = left + col * (cell + 6f);
            var y = rect.Y + headH + 4f + row * (cell + 6f);

            var value = (float)Days[d];
            var intensity = value <= 0 ? 0f : 0.15f + 0.85f * (value / peak);

            canvas.FillColor = value <= 0 ? Palette.Rule : Palette.Ink.WithAlpha(intensity);
            canvas.FillRoundedRectangle(x, y, cell, cell, 7f);

            canvas.FontSize = 10f;
            canvas.FontColor = intensity > 0.55f ? Palette.Card : Palette.Muted;
            canvas.DrawString((d + 1).ToString(), x, y, cell, cell, HAlign.Center, VAlign.Center);
        }
    }

    public float HeightFor(float width)
    {
        var cell = Math.Min((width - 6 * 6f) / 7f, 40f);
        var rows = (int)Math.Ceiling((FirstWeekday + Math.Max(1, Days.Count)) / 7.0);
        return 18f + 4f + rows * (cell + 6f);
    }
}

/// <summary>
/// The runway. A wedge that thins as it runs out — thick while you have room,
/// tapering to a point as the money does. The one bit of character in the app.
/// </summary>
public class RunwayWedge : IDrawable
{
    /// <summary>0..1 of a 120-day horizon.</summary>
    public float Fraction { get; set; }
    public bool HasData { get; set; }

    public void Draw(ICanvas canvas, RectF rect)
    {
        canvas.Antialias = true;

        var y = rect.Y + rect.Height / 2f;
        const float thick = 11f;
        const float thin = 3f;

        // the unlit remainder
        var ghost = new PathF();
        ghost.MoveTo(rect.X, y - thick / 2f);
        ghost.LineTo(rect.Right, y - thin / 2f);
        ghost.LineTo(rect.Right, y + thin / 2f);
        ghost.LineTo(rect.X, y + thick / 2f);
        ghost.Close();
        canvas.FillColor = Palette.Rule;
        canvas.FillPath(ghost);

        if (!HasData || Fraction <= 0f) return;

        var f = Math.Clamp(Fraction, 0.04f, 1f);
        var endX = rect.X + rect.Width * f;
        var endHalf = (thick + (thin - thick) * f) / 2f;

        var wedge = new PathF();
        wedge.MoveTo(rect.X, y - thick / 2f);
        wedge.LineTo(endX, y - endHalf);
        wedge.LineTo(endX, y + endHalf);
        wedge.LineTo(rect.X, y + thick / 2f);
        wedge.Close();
        canvas.FillColor = Palette.Ink;
        canvas.FillPath(wedge);

        // the burn point
        canvas.FillColor = Palette.Ink;
        canvas.FillCircle(endX, y, 4.5f);
        canvas.FillColor = Palette.Card;
        canvas.FillCircle(endX, y, 2f);
    }
}
