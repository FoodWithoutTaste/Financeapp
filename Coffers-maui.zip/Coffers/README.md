# Coffers

A personal ledger for Android. Log every payment, see where it goes, and know how
long your money lasts.

Written in C# with .NET MAUI. **No third-party NuGet packages** — the charts are
hand-drawn with `Microsoft.Maui.Graphics`, so there's nothing to license and nothing
to break on restore.

---

## Getting it on your phone

You need the .NET SDK and the MAUI Android workload. If you've built for Android from
Unity before, the Android SDK part will already look familiar.

### 1. Install the toolchain

```bash
dotnet workload install maui-android
```

Check it took:

```bash
dotnet workload list
```

### 2. Run it on your phone

No scaffolding needed — the project is complete, including its own `.csproj`, app icon
and splash screen. There are no binary assets and no NuGet packages, so `dotnet` has
everything it needs the moment you unzip.

Enable Developer Options and USB debugging on the phone, plug it in, then:

```bash
cd Coffers
dotnet build -t:Run
```

The project targets `net9.0-android`. If you're on the .NET 10 SDK, change the
`<TargetFramework>` line in `Coffers.csproj` to `net10.0-android`.

### 3. Build a standalone APK

```bash
dotnet publish -c Release -p:AndroidPackageFormat=apk
```

The APK lands in:

```
bin/Release/net9.0-android/publish/com.heartstuck.coffers-Signed.apk
```

Copy it to the phone and open it. Android will ask you to allow installing from unknown
sources — that's expected for anything not from the Play Store.

To change the app's name or package id, edit these in `Coffers.csproj`:

```xml
<ApplicationTitle>Coffers</ApplicationTitle>
<ApplicationId>com.heartstuck.coffers</ApplicationId>
```


---

## Building it from your phone only (no PC at all)

GitHub will build the APK for you on their machines, for free. Every step below
happens in your phone's browser.

1. **Make a repo.** github.com → New repository → name it `coffers` → tick
   *Add a README* so the repo isn't empty → Create.

2. **Upload the zip.** Add file → Upload files → pick `Coffers-maui.zip` from your
   Downloads → Commit. Leave it zipped; the build unpacks it.

3. **Add the workflow.** Add file → Create new file. In the filename box type exactly:

   ```
   .github/workflows/build-apk.yml
   ```

   Typing the slashes creates the folders. Paste in the contents of `build-apk.yml`
   and commit.

4. **Wait.** The Actions tab shows the build running. First run takes about 10 minutes,
   mostly installing the Android workload.

5. **Download the APK.** Open the finished run → scroll to *Artifacts* → tap
   `coffers-apk`. It downloads as a zip; unzip it with your phone's Files app and
   tap the `.apk` inside.

6. **Let Android install it.** It will refuse the first time and offer a settings link.
   Allow *Install unknown apps* for whichever app you opened the file from, then tap
   install again. That permission is per-app, so allowing it for Files doesn't allow
   it for Drive.

### When the build fails

It probably will, the first time. Open the failed run, tap the red step, and copy the
error. To fix it you replace the zip: delete `Coffers-maui.zip` in the repo (open it →
the three-dot menu → Delete), upload the corrected one, and the build kicks off again.

### Notes

- The APK is signed with a debug key. That's fine for your own phone; you'd need a
  proper keystore only to publish on Play.
- Public repos get unlimited Actions minutes. Private ones get 2,000 a month, and this
  build uses about 10.

---

## How it's put together

```
Coffers.csproj           Everything the build needs. No packages, no binary assets.
Models/Book.cs           Transaction, Goal, AppSettings, categories, money formatting
Services/BookStore.cs    Load and save. Atomic writes with a rolling backup.
Services/Insights.cs     Reads the month and says something true about it.
Drawables/Charts.cs      Bar chart, pace chart, runway wedge. Hand-drawn.
ViewModels/Mvvm.cs       Observable base and command types. No packages.
ViewModels/MainViewModel Everything derived, recomputed in one pass.
Views/MainPage           Balance, runway, goals, notes, charts, entries.
Views/EntryPage          Custom keypad. Four taps to log a payment.
Views/SettingsPage       Currency, starting balance, backup and restore.
Views/GoalsPage          What the money is actually for.
```

### About the data

The ledger is a single JSON file in the app's private storage. Saving writes to a temp
file, copies the previous version to `.bak`, then swaps the new file in. A crash
mid-write can't corrupt your book, and if the main file is ever unreadable the app falls
back to the backup and tells you it did.

That said, uninstalling the app deletes it. **Use Settings → Send CSV every so often**
and mail it to yourself.

### Reviewing your spending

Settings → Send CSV produces a plain `date,type,category,amount,note` file. Send it to
yourself and paste it into a chat when you want a second pair of eyes on where the money
is going — that's what it's shaped for.

---

## What's in it

**The numbers**
- Balance, and what's come in and gone out this month
- Runway — how many days the coffers last at your current burn rate
- Average spend a day, biggest single expense, entry count

**Keeping the habit**
- A custom keypad, so a payment is about four taps
- One-tap repeats: anything you've logged twice in the last four months
  becomes a chip on the entry screen
- Nightly reminder notification, at a time you pick
- A streak of nights recorded, with a "quiet night" button so days you
  spend nothing still count

**Seeing it**
- Where it went: spend by category
- Pace: this month's cumulative spend against last month's
- Balance: month-end balance across the last year
- Days: the month as a calendar, each day shaded by what went out
- Biggest this month: the five that hurt most
- Notes from the ledger: plain observations about what changed

**Look**
- Light and dark. Settings → Appearance: match your phone, Paper, or Ink.
  Dark isn't an inversion — the slate keeps the paper's faint green cast, and the
  category hues are lifted, because the paper ones turn to mud on a dark ground.
  The widget follows your phone's setting rather than the in-app one, as widgets do.

**Habit**
- Home screen widget: balance, runway, and a one-tap record button.
  Long-press the home screen → Widgets → Coffers.
- The worth-it tap: a week after any payment over your threshold, Coffers asks
  whether it was worth it. Two buttons, no typing. Asking late is the point —
  at the till everything feels worth it.
- Standing: personal bests you chase against your own record — cheapest week,
  longest run kept, best month, longest spend-free run. Records only count on
  days the ledger was actually kept, so the board can never reward going quiet.

**Automation**
- Recurring payments: rent, subscriptions, the gym — recorded for you when
  their day of the month arrives, never twice, never back-filled

**Control**
- Monthly budgets per category, with over-budget warnings
- Savings goals with finish dates based on your actual net
- Search across notes, categories and amounts
- Duplicate an entry, and undo a delete
- CSV export (now carrying your worth-it verdicts) and a full JSON backup
- Reconcile: type what you actually have and the starting figure shifts to match
- Put money aside toward a goal straight from the main screen

## Things you'll want to change first

1. **Settings → balance right now.** It ships at 90 000. Type what you actually have.
2. **Settings → currency.** Defaults to CZK.
3. **Saving toward → goals.** Two are pre-filled: moving out, and Chug It marketing.
   Put your real targets in.
4. **◧ Budgets.** Set monthly ceilings on the categories you actually want to hold down.
5. **Settings → nightly reminder.** Off by default. Android will ask permission the
   first time you turn it on.

---

## Design notes

The interface is ink on paper and nothing else. The only colour in the app is money:
green for what came in, red for what went out, and the category hues in the chart.
Everything else stays quiet so the numbers carry.

The runway wedge is the one bit of character — a shape that thins as your money does,
showing how many days the coffers last at your current burn rate. It's the number that
makes you think twice before a purchase, which is more than a pie chart ever managed.

The streak counts nights recorded, and there's a "quiet night" button so days you spend
nothing still count. A habit tracker that punishes you for not spending money would be
a strange thing to build.
