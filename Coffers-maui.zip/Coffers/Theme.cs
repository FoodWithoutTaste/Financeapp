using Microsoft.Maui.Storage;

namespace Coffers;

/// <summary>
/// Two palettes, one idea. Light is ink on paper. Dark is the same page after hours —
/// a deep slate that keeps the paper's faint green cast rather than going flat black,
/// with the ink and the surface simply trading places. Money keeps its meaning in both,
/// but the greens and reds are lifted for a dark ground where the light ones go muddy.
///
/// XAML reads these through AppThemeBinding, code-behind and the hand-drawn charts read
/// them through here, so there is exactly one place a colour is decided.
/// </summary>
public static class Theme
{
    public const string PrefKey = "coffers.appearance";

    public const string System = "system";
    public const string Light = "light";
    public const string Dark = "dark";

    public static string Mode
    {
        get
        {
            try { return Preferences.Default.Get(PrefKey, System); }
            catch { return System; }
        }
    }

    public static bool IsDark => Application.Current?.RequestedTheme == AppTheme.Dark;

    /// <summary>The remembered choice as MAUI wants it. Unspecified means follow the phone.</summary>
    public static AppTheme Requested => Mode switch
    {
        Light => AppTheme.Light,
        Dark => AppTheme.Dark,
        _ => AppTheme.Unspecified,
    };

    /// <summary>Switches the app over and remembers the choice.</summary>
    public static void Apply(string mode)
    {
        try { Preferences.Default.Set(PrefKey, mode); } catch { }

        if (Application.Current is null) return;

        Application.Current.UserAppTheme = Requested;

        PaintSystemChrome();
    }

    /// <summary>Called once at startup to restore the remembered choice.</summary>
    public static void Restore() => Apply(Mode);

    // ---------- the palette ----------

    private static Color Pick(string light, string dark) =>
        Color.FromArgb(IsDark ? dark : light);

    public static Color Paper    => Pick("#F7F8F6", "#141613");
    public static Color Card     => Pick("#FFFFFF", "#1C201C");
    public static Color Rule     => Pick("#E4E9E4", "#2E332D");
    public static Color RuleSoft => Pick("#EFF2EF", "#242821");
    public static Color Ink      => Pick("#151A17", "#ECEFEA");
    public static Color InkSoft  => Pick("#3A443E", "#C2C9C0");
    public static Color Muted    => Pick("#71807A", "#8D968F");
    public static Color Faint    => Pick("#9AA6A0", "#737D76");

    public static Color MoneyIn  => Pick("#2E8B57", "#4FBE7E");
    public static Color MoneyOut => Pick("#C8503F", "#E8705C");

    /// <summary>The wash behind a problem banner.</summary>
    public static Color Alarm    => Pick("#FDF1EF", "#2C1A17");

    /// <summary>
    /// A category hue, adjusted for the ground it sits on. The stored hexes are
    /// tuned for paper; on a dark page they're lifted toward white or they turn to mud.
    /// </summary>
    public static Color Tint(string hex)
    {
        var c = Color.FromArgb(hex);
        if (!IsDark) return c;

        const float lift = 0.26f;
        return new Color(
            c.Red + (1f - c.Red) * lift,
            c.Green + (1f - c.Green) * lift,
            c.Blue + (1f - c.Blue) * lift);
    }

    // ---------- system bars ----------

    /// <summary>Makes the status and navigation bars match the page they sit against.</summary>
    public static void PaintSystemChrome()
    {
#if ANDROID
        try
        {
            var window = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity?.Window;
            if (window is null) return;

            var shade = Android.Graphics.Color.ParseColor(IsDark ? "#141613" : "#F7F8F6");
            window.SetStatusBarColor(shade);
            window.SetNavigationBarColor(shade);

            if (OperatingSystem.IsAndroidVersionAtLeast(30))
            {
                // APPEARANCE_LIGHT_STATUS_BARS | APPEARANCE_LIGHT_NAVIGATION_BARS —
                // dark glyphs, which is what a light bar needs and a dark bar must not have.
                const int lightBars = 8 | 16;
                window.InsetsController?.SetSystemBarsAppearance(IsDark ? 0 : lightBars, lightBars);
            }
        }
        catch
        {
            // Cosmetic. Never worth a crash.
        }
#endif
    }
}
