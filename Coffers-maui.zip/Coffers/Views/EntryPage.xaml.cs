using System.Globalization;
using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class EntryPage : ContentPage
{
    private readonly MainViewModel _vm;
    private readonly Transaction? _existing;

    private Flow _flow = Flow.Out;
    private string _raw = "";
    private string _category = "food";
    private readonly Dictionary<string, Button> _chips = new();

    private static Color Ink => (Color)Application.Current!.Resources["Ink"];
    private static Color Card => (Color)Application.Current!.Resources["Card"];
    private static Color Muted => (Color)Application.Current!.Resources["Muted"];
    private static Color Faint => (Color)Application.Current!.Resources["Faint"];
    private static Color Rule => (Color)Application.Current!.Resources["Rule"];

    public EntryPage(MainViewModel vm, Transaction? existing = null)
    {
        InitializeComponent();
        _vm = vm;
        _existing = existing;

        DateField.MaximumDate = DateTime.Today;
        DateField.Date = DateTime.Today;
        SymbolLabel.Text = Money.Symbol(_vm.Currency);

        if (existing is not null)
        {
            Heading.Text = "Edit entry";
            Title = "Edit entry";
            SaveButton.Text = "Save changes";
            DeleteButton.IsVisible = true;

            _flow = existing.Type;
            _category = existing.Category;
            _raw = existing.Amount == Math.Floor(existing.Amount)
                ? ((long)existing.Amount).ToString(CultureInfo.InvariantCulture)
                : existing.Amount.ToString("0.##", CultureInfo.InvariantCulture);
            NoteEntry.Text = existing.Note;
            DateField.Date = existing.When;
        }

        ApplyFlow();
        ShowAmount();
    }

    // ---------- direction ----------

    private void OnPaidOut(object sender, EventArgs e) { _flow = Flow.Out; ApplyFlow(); }
    private void OnCameIn(object sender, EventArgs e) { _flow = Flow.In; ApplyFlow(); }

    private void ApplyFlow()
    {
        var outSelected = _flow == Flow.Out;

        OutTab.BackgroundColor = outSelected ? Card : Colors.Transparent;
        OutTab.TextColor = outSelected ? Ink : Muted;
        OutTab.FontAttributes = outSelected ? FontAttributes.Bold : FontAttributes.None;

        InTab.BackgroundColor = outSelected ? Colors.Transparent : Card;
        InTab.TextColor = outSelected ? Muted : Ink;
        InTab.FontAttributes = outSelected ? FontAttributes.None : FontAttributes.Bold;

        BuildChips();
    }

    // ---------- categories ----------

    private void BuildChips()
    {
        ChipBox.Children.Clear();
        _chips.Clear();

        var options = Categories.For(_flow).ToList();
        if (options.All(c => c.Id != _category))
            _category = options[0].Id;

        foreach (var cat in options)
        {
            var chip = new Button
            {
                Text = cat.Label,
                FontSize = 12,
                CornerRadius = 18,
                HeightRequest = 36,
                Padding = new Thickness(14, 0),
                BorderWidth = 1,
                Margin = new Thickness(0, 0, 6, 6),
                BackgroundColor = Colors.Transparent,
            };
            var id = cat.Id;
            chip.Clicked += (_, _) => { _category = id; PaintChips(); };
            _chips[id] = chip;
            ChipBox.Children.Add(chip);
        }

        PaintChips();
    }

    private void PaintChips()
    {
        foreach (var (id, chip) in _chips)
        {
            var selected = id == _category;
            var hue = Categories.ColorOf(id);
            chip.BorderColor = selected ? hue : Rule;
            chip.TextColor = selected ? hue : Muted;
            chip.BackgroundColor = selected ? hue.WithAlpha(0.10f) : Colors.Transparent;
            chip.FontAttributes = selected ? FontAttributes.Bold : FontAttributes.None;
        }
    }

    // ---------- keypad ----------

    private void OnKey(object sender, EventArgs e)
    {
        if (sender is not Button b) return;
        var k = b.Text;

        if (k == ".")
        {
            if (_raw.Contains('.')) return;
            _raw = _raw.Length == 0 ? "0." : _raw + ".";
        }
        else
        {
            var dot = _raw.IndexOf('.');
            if (dot >= 0 && _raw.Length - dot > 2) return;   // two decimals is plenty
            if (_raw == "0") _raw = k;
            else if (_raw.Length < 11) _raw += k;
        }

        ShowAmount();
    }

    private void OnBackspace(object sender, EventArgs e)
    {
        if (_raw.Length > 0) _raw = _raw[..^1];
        ShowAmount();
    }

    private void ShowAmount()
    {
        AmountLabel.Text = _raw.Length == 0 ? "0" : _raw;
        AmountLabel.TextColor = _raw.Length == 0 ? Faint : Ink;
        SaveButton.IsEnabled = Parsed > 0m;
        SaveButton.Opacity = Parsed > 0m ? 1 : 0.4;
    }

    private decimal Parsed =>
        decimal.TryParse(_raw, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : 0m;

    // ---------- save ----------

    private async void OnSave(object sender, EventArgs e)
    {
        var amount = Parsed;
        if (amount <= 0m) return;

        var tx = new Transaction
        {
            Id = _existing?.Id ?? Guid.NewGuid().ToString("N")[..10],
            Type = _flow,
            Amount = amount,
            Category = _category,
            Note = (NoteEntry.Text ?? "").Trim(),
            Date = DateField.Date.ToString("yyyy-MM-dd"),
        };

        await _vm.AddOrUpdateAsync(tx);
        await Navigation.PopAsync();
    }

    private async void OnDelete(object sender, EventArgs e)
    {
        if (_existing is null) return;

        var sure = await DisplayAlert(
            "Delete this entry?",
            "It will be removed from the ledger. This can't be undone.",
            "Delete", "Keep it");

        if (!sure) return;

        await _vm.DeleteAsync(_existing.Id);
        await Navigation.PopAsync();
    }
}
