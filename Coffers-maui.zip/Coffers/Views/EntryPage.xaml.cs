using System.Globalization;
using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class EntryPage : ContentPage
{
    private readonly MainViewModel _vm;
    private Transaction? _existing;

    private Flow _flow = Flow.Out;
    private string _raw = "";
    private string _category = "food";
    private readonly Dictionary<string, Button> _chips = new();

    private static Color Ink => Theme.Ink;
    private static Color Card => Theme.Card;
    private static Color Muted => Theme.Muted;
    private static Color Faint => Theme.Faint;
    private static Color Rule => Theme.Rule;

    public EntryPage(MainViewModel vm, Transaction? existing = null)
    {
        InitializeComponent();
        _vm = vm;
        _existing = existing;

        DateField.MaximumDate = DateTime.Today;
        DateField.Date = DateTime.Today;
        SymbolLabel.Text = Money.Symbol(_vm.Currency);

        if (existing is not null)
        {
            Heading.Text = "Edit entry";
            Title = "Edit entry";
            SaveButton.Text = "Save changes";
            DeleteButton.IsVisible = true;
            DuplicateButton.IsVisible = true;

            _flow = existing.Type;
            _category = existing.Category;
            _raw = Plain(existing.Amount);
            NoteEntry.Text = existing.Note;
            DateField.Date = existing.When;
        }
        else
        {
            BuildQuickEntries();
        }

        ApplyFlow();
        ShowAmount();
    }

    private static string Plain(decimal d) =>
        d == Math.Floor(d)
            ? ((long)d).ToString(CultureInfo.InvariantCulture)
            : d.ToString("0.##", CultureInfo.InvariantCulture);

    // ---------- one-tap repeats ----------

    private void BuildQuickEntries()
    {
        var quick = _vm.QuickEntries();
        if (quick.Count == 0) return;

        QuickPane.IsVisible = true;

        foreach (var q in quick)
        {
            var button = new Button
            {
                Text = $"{q.Label}  ·  {q.Detail}",
                FontSize = 12,
                CornerRadius = 18,
                HeightRequest = 38,
                Padding = new Thickness(14, 0),
                BorderWidth = 1,
                BorderColor = Rule,
                TextColor = Ink,
                BackgroundColor = q.Hue.WithAlpha(0.08f),
                Margin = new Thickness(0, 0, 6, 6),
            };

            var item = q;
            button.Clicked += (_, _) =>
            {
                Tap();
                _flow = item.Type;
                _category = item.Category;
                _raw = Plain(item.Amount);
                NoteEntry.Text = item.Note;
                DateField.Date = DateTime.Today;
                ApplyFlow();
                ShowAmount();
            };

            QuickBox.Children.Add(button);
        }
    }

    // ---------- direction ----------

    private void OnPaidOut(object sender, EventArgs e) { Tap(); _flow = Flow.Out; ApplyFlow(); }
    private void OnCameIn(object sender, EventArgs e) { Tap(); _flow = Flow.In; ApplyFlow(); }

    private void ApplyFlow()
    {
        var outSelected = _flow == Flow.Out;

        OutTab.BackgroundColor = outSelected ? Card : Colors.Transparent;
        OutTab.TextColor = outSelected ? Ink : Muted;
        OutTab.FontAttributes = outSelected ? FontAttributes.Bold : FontAttributes.None;

        InTab.BackgroundColor = outSelected ? Colors.Transparent : Card;
        InTab.TextColor = outSelected ? Muted : Ink;
        InTab.FontAttributes = outSelected ? FontAttributes.None : FontAttributes.Bold;

        BuildChips();
    }

    // ---------- categories ----------

    private void BuildChips()
    {
        ChipBox.Children.Clear();
        _chips.Clear();

        var options = Categories.For(_flow).ToList();
        if (options.All(c => c.Id != _category)) _category = options[0].Id;

        foreach (var cat in options)
        {
            var chip = new Button
            {
                Text = cat.Label,
                FontSize = 12,
                CornerRadius = 18,
                HeightRequest = 36,
                Padding = new Thickness(14, 0),
                BorderWidth = 1,
                Margin = new Thickness(0, 0, 6, 6),
                BackgroundColor = Colors.Transparent,
            };
            var id = cat.Id;
            chip.Clicked += (_, _) => { Tap(); _category = id; PaintChips(); };
            _chips[id] = chip;
            ChipBox.Children.Add(chip);
        }

        PaintChips();
    }

    private void PaintChips()
    {
        foreach (var (id, chip) in _chips)
        {
            var selected = id == _category;
            var hue = Categories.ColorOf(id);
            chip.BorderColor = selected ? hue : Rule;
            chip.TextColor = selected ? hue : Muted;
            chip.BackgroundColor = selected ? hue.WithAlpha(0.10f) : Colors.Transparent;
            chip.FontAttributes = selected ? FontAttributes.Bold : FontAttributes.None;
        }
    }

    // ---------- dates ----------

    private void OnToday(object sender, EventArgs e) { Tap(); DateField.Date = DateTime.Today; }
    private void OnYesterday(object sender, EventArgs e) { Tap(); DateField.Date = DateTime.Today.AddDays(-1); }

    private void OnDuplicate(object sender, EventArgs e)
    {
        Tap();
        _existing = null;
        Heading.Text = "New entry";
        Title = "New entry";
        SaveButton.Text = "Record it";
        DeleteButton.IsVisible = false;
        DuplicateButton.IsVisible = false;
        DateField.Date = DateTime.Today;
    }

    // ---------- keypad ----------

    private void OnKey(object sender, EventArgs e)
    {
        if (sender is not Button b) return;
        Tap();
        var k = b.Text;

        if (k == ".")
        {
            if (_raw.Contains('.')) return;
            _raw = _raw.Length == 0 ? "0." : _raw + ".";
        }
        else
        {
            var dot = _raw.IndexOf('.');
            if (dot >= 0 && _raw.Length - dot > 2) return;
            if (_raw == "0") _raw = k;
            else if (_raw.Length < 11) _raw += k;
        }

        ShowAmount();
    }

    private void OnBackspace(object sender, EventArgs e)
    {
        Tap();
        if (_raw.Length > 0) _raw = _raw[..^1];
        ShowAmount();
    }

    private void ShowAmount()
    {
        AmountLabel.Text = _raw.Length == 0 ? "0" : _raw;
        AmountLabel.TextColor = _raw.Length == 0 ? Faint : Ink;
        SaveButton.IsEnabled = Parsed > 0m;
        SaveButton.Opacity = Parsed > 0m ? 1 : 0.4;
    }

    private decimal Parsed =>
        decimal.TryParse(_raw, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : 0m;

    /// <summary>A short tick so the keypad feels like a keypad. Never allowed to throw.</summary>
    private static void Tap()
    {
        try { HapticFeedback.Default.Perform(HapticFeedbackType.Click); }
        catch { }
    }

    // ---------- save ----------

    private async void OnSave(object sender, EventArgs e)
    {
        var amount = Parsed;
        if (amount <= 0m) return;

        Tap();

        await _vm.AddOrUpdateAsync(new Transaction
        {
            Id = _existing?.Id ?? Guid.NewGuid().ToString("N")[..10],
            Type = _flow,
            Amount = amount,
            Category = _category,
            Note = (NoteEntry.Text ?? "").Trim(),
            Date = DateField.Date.ToString("yyyy-MM-dd"),

            // Editing a line shouldn't put it back in the worth-it queue.
            Verdict = _existing?.Verdict ?? 0,
        });

        await Navigation.PopAsync();
    }

    private async void OnDelete(object sender, EventArgs e)
    {
        if (_existing is null) return;

        var sure = await DisplayAlert("Delete this entry?",
            "You'll get one chance to undo it on the way back.", "Delete", "Keep it");
        if (!sure) return;

        await _vm.DeleteAsync(_existing.Id);
        await Navigation.PopAsync();
    }
}
