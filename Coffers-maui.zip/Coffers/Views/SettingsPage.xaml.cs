using System.Globalization;
using Coffers.Models;
using Coffers.Services;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class SettingsPage : ContentPage
{
    private readonly MainViewModel _vm;
    private string _currency;
    private readonly Dictionary<string, Button> _chips = new();

    private static Color Ink => (Color)Application.Current!.Resources["Ink"];
    private static Color Muted => (Color)Application.Current!.Resources["Muted"];
    private static Color Rule => (Color)Application.Current!.Resources["Rule"];

    public SettingsPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        _currency = vm.Book.Settings.Currency;

        OpeningEntry.Text = vm.Book.Settings.Opening.ToString("0.##", CultureInfo.InvariantCulture);

        ReminderSwitch.IsToggled = vm.Book.Reminder.Enabled;
        TimeShell.IsVisible = vm.Book.Reminder.Enabled;
        ReminderTime.Time = new TimeSpan(vm.Book.Reminder.Hour, vm.Book.Reminder.Minute, 0);

        BuildCurrencies();
    }

    private void BuildCurrencies()
    {
        foreach (var code in Money.Codes)
        {
            var chip = new Button
            {
                Text = $"{Money.Symbol(code)}  {code}",
                FontSize = 12.5,
                CornerRadius = 18,
                HeightRequest = 38,
                Padding = new Thickness(15, 0),
                BorderWidth = 1,
                Margin = new Thickness(0, 0, 7, 7),
                BackgroundColor = Colors.Transparent,
            };
            var c = code;
            chip.Clicked += (_, _) => { _currency = c; PaintCurrencies(); };
            _chips[code] = chip;
            CurrencyBox.Children.Add(chip);
        }
        PaintCurrencies();
    }

    private void PaintCurrencies()
    {
        foreach (var (code, chip) in _chips)
        {
            var on = code == _currency;
            chip.BorderColor = on ? Ink : Rule;
            chip.TextColor = on ? Ink : Muted;
            chip.FontAttributes = on ? FontAttributes.Bold : FontAttributes.None;
        }
    }

    private async void OnReminderToggled(object sender, ToggledEventArgs e)
    {
        TimeShell.IsVisible = e.Value;

        if (!e.Value) return;

        var granted = await Reminders.RequestPermissionAsync();
        if (!granted)
        {
            ReminderSwitch.IsToggled = false;
            TimeShell.IsVisible = false;
            Say("Android turned notifications down. Allow them for Coffers in system settings, then try again.");
        }
    }

    private async void OnSave(object sender, EventArgs e)
    {
        var text = (OpeningEntry.Text ?? "0").Replace(',', '.').Trim();
        if (!decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var opening))
        {
            Say("That starting balance isn't a number. Digits only.");
            return;
        }

        _vm.Book.Settings.Currency = _currency;
        _vm.Book.Settings.Opening = opening;
        _vm.Book.Reminder.Enabled = ReminderSwitch.IsToggled;
        _vm.Book.Reminder.Hour = ReminderTime.Time.Hours;
        _vm.Book.Reminder.Minute = ReminderTime.Time.Minutes;

        await _vm.SaveAsync();
        _vm.ApplyReminder();
        await Navigation.PopAsync();
    }

    private async void OnShareCsv(object sender, EventArgs e)
    {
        try { await _vm.ShareCsvAsync(); }
        catch (Exception ex) { Say($"Couldn't share that: {ex.Message}"); }
    }

    private async void OnCopyBackup(object sender, EventArgs e)
    {
        await Clipboard.Default.SetTextAsync(_vm.ToJson());
        Say("Backup copied. Paste it somewhere safe — an email to yourself works.");
    }

    private async void OnRestore(object sender, EventArgs e)
    {
        var json = await Clipboard.Default.GetTextAsync();
        if (string.IsNullOrWhiteSpace(json))
        {
            Say("Nothing on the clipboard. Copy a backup first, then tap this.");
            return;
        }

        var sure = await DisplayAlert("Replace everything?",
            "Restoring overwrites the ledger currently on this phone.", "Restore", "Cancel");
        if (!sure) return;

        if (await _vm.RestoreAsync(json)) await Navigation.PopAsync();
        else Say("That clipboard text isn't a backup this app can read.");
    }

    private void Say(string message)
    {
        Feedback.Text = message;
        Feedback.IsVisible = true;
    }
}
