using System.Globalization;
using Coffers.Models;
using Coffers.Services;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class SettingsPage : ContentPage
{
    private readonly MainViewModel _vm;
    private string _currency;
    private readonly Dictionary<string, Button> _chips = new();
    private bool _ready;

    private static Color Ink => Theme.Ink;
    private static Color Muted => Theme.Muted;
    private static Color Rule => Theme.Rule;

    public SettingsPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        _currency = vm.Book.Settings.Currency;

        OpeningEntry.Text = vm.CurrentBalance.ToString("0.##", CultureInfo.InvariantCulture);
        RefreshRecurringLabel();

        for (var d = 1; d <= 21; d++)
            DelayPicker.Items.Add(d == 1 ? "1 day" : $"{d} days");
        DelayPicker.SelectedIndex = Math.Clamp(vm.Book.Settings.WorthItDelay, 1, 21) - 1;

        ThemePicker.Items.Add("Match my phone");
        ThemePicker.Items.Add("Paper — light");
        ThemePicker.Items.Add("Ink — dark");
        ThemePicker.SelectedIndex = Theme.Mode switch
        {
            Theme.Light => 1,
            Theme.Dark => 2,
            _ => 0,
        };

        FloorEntry.Text = vm.Book.Settings.WorthItFloor.ToString("0.##", CultureInfo.InvariantCulture);
        WorthItSwitch.IsToggled = vm.Book.Settings.WorthIt;
        WorthItBox.IsVisible = vm.Book.Settings.WorthIt;

        ReminderSwitch.IsToggled = vm.Book.Reminder.Enabled;
        TimeShell.IsVisible = vm.Book.Reminder.Enabled;
        ReminderTime.Time = new TimeSpan(vm.Book.Reminder.Hour, vm.Book.Reminder.Minute, 0);

        BuildCurrencies();

        _ready = true;
    }

    private void BuildCurrencies()
    {
        foreach (var code in Money.Codes)
        {
            var chip = new Button
            {
                Text = $"{Money.Symbol(code)}  {code}",
                FontSize = 12.5,
                CornerRadius = 18,
                HeightRequest = 38,
                Padding = new Thickness(15, 0),
                BorderWidth = 1,
                Margin = new Thickness(0, 0, 7, 7),
                BackgroundColor = Colors.Transparent,
            };
            var c = code;
            chip.Clicked += (_, _) => { _currency = c; PaintCurrencies(); };
            _chips[code] = chip;
            CurrencyBox.Children.Add(chip);
        }
        PaintCurrencies();
    }

    private void PaintCurrencies()
    {
        foreach (var (code, chip) in _chips)
        {
            var on = code == _currency;
            chip.BorderColor = on ? Ink : Rule;
            chip.TextColor = on ? Ink : Muted;
            chip.FontAttributes = on ? FontAttributes.Bold : FontAttributes.None;
        }
    }

    private async void OnReminderToggled(object sender, ToggledEventArgs e)
    {
        TimeShell.IsVisible = e.Value;

        if (!e.Value) return;

        var granted = await Reminders.RequestPermissionAsync();
        if (!granted)
        {
            ReminderSwitch.IsToggled = false;
            TimeShell.IsVisible = false;
            Say("Android turned notifications down. Allow them for Coffers in system settings, then try again.");
        }
    }

    private void OnWorthItToggled(object sender, ToggledEventArgs e) =>
        WorthItBox.IsVisible = e.Value;

    /// <summary>
    /// Applies immediately rather than waiting for Save — you pick a look to see it,
    /// and a theme you have to confirm feels broken.
    /// </summary>
    private void OnThemePicked(object sender, EventArgs e)
    {
        if (!_ready) return;

        Theme.Apply(ThemePicker.SelectedIndex switch
        {
            1 => Theme.Light,
            2 => Theme.Dark,
            _ => Theme.System,
        });

        // The currency chips carry colours set in code, so they need repainting by hand.
        PaintCurrencies();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        RefreshRecurringLabel();
    }

    private void RefreshRecurringLabel()
    {
        var n = _vm.Book.Recurring.Count;
        RecurringButton.Text = n == 0
            ? "Manage recurring payments"
            : $"Manage recurring payments ({n})";
    }

    private async void OnRecurring(object sender, EventArgs e) =>
        await Navigation.PushAsync(new RecurringPage(_vm));

    private async void OnSave(object sender, EventArgs e)
    {
        var text = (OpeningEntry.Text ?? "0").Replace(',', '.').Trim();
        if (!decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var actual))
        {
            Say("That balance isn't a number. Digits only.");
            return;
        }

        // Shift the opening figure so the running total lands on what you typed.
        _vm.Book.Settings.Opening += actual - _vm.CurrentBalance;
        _vm.Book.Settings.Currency = _currency;

        _vm.Book.Settings.WorthIt = WorthItSwitch.IsToggled;
        _vm.Book.Settings.WorthItDelay = Math.Clamp(DelayPicker.SelectedIndex + 1, 1, 21);

        var floorText = (FloorEntry.Text ?? "").Replace(',', '.').Trim();
        if (decimal.TryParse(floorText, NumberStyles.Any, CultureInfo.InvariantCulture, out var floor) && floor >= 0)
            _vm.Book.Settings.WorthItFloor = floor;
        _vm.Book.Reminder.Enabled = ReminderSwitch.IsToggled;
        _vm.Book.Reminder.Hour = ReminderTime.Time.Hours;
        _vm.Book.Reminder.Minute = ReminderTime.Time.Minutes;

        await _vm.SaveAsync();
        _vm.ApplyReminder();
        await Navigation.PopAsync();
    }

    private async void OnShareCsv(object sender, EventArgs e)
    {
        try { await _vm.ShareCsvAsync(); }
        catch (Exception ex) { Say($"Couldn't share that: {ex.Message}"); }
    }

    private async void OnCopyBackup(object sender, EventArgs e)
    {
        await Clipboard.Default.SetTextAsync(_vm.ToJson());
        Say("Backup copied. Paste it somewhere safe — an email to yourself works.");
    }

    private async void OnRestore(object sender, EventArgs e)
    {
        var json = await Clipboard.Default.GetTextAsync();
        if (string.IsNullOrWhiteSpace(json))
        {
            Say("Nothing on the clipboard. Copy a backup first, then tap this.");
            return;
        }

        var sure = await DisplayAlert("Replace everything?",
            "Restoring overwrites the ledger currently on this phone.", "Restore", "Cancel");
        if (!sure) return;

        if (await _vm.RestoreAsync(json)) await Navigation.PopAsync();
        else Say("That clipboard text isn't a backup this app can read.");
    }

    private void Say(string message)
    {
        Feedback.Text = message;
        Feedback.IsVisible = true;
    }
}
