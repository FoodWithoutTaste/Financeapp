using System.Globalization;
using Microsoft.Maui.Controls.Shapes;
using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class BudgetsPage : ContentPage
{
    private readonly MainViewModel _vm;
    private readonly Dictionary<string, Entry> _fields = new();

    public BudgetsPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;
        Build();
    }

    private void Build()
    {
        Rows.Children.Clear();
        _fields.Clear();

        foreach (var cat in Categories.Outgoing)
        {
            var current = _vm.Book.Budgets.FirstOrDefault(b => b.Category == cat.Id);

            var field = new Entry
            {
                Text = current is { Monthly: > 0 }
                    ? current.Monthly.ToString("0.##", CultureInfo.InvariantCulture)
                    : "",
                Placeholder = "no limit",
                Keyboard = Keyboard.Numeric,
                HeightRequest = 46,
                HorizontalTextAlignment = TextAlignment.End,
            };
            _fields[cat.Id] = field;

            var swatch = new Border
            {
                BackgroundColor = Color.FromArgb(cat.Hex),
                Stroke = Colors.Transparent,
                WidthRequest = 10,
                HeightRequest = 10,
                VerticalOptions = LayoutOptions.Center,
                StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(5) },
            };

            var label = new Label
            {
                Text = cat.Label,
                Style = (Style)Application.Current!.Resources["Body"],
                VerticalOptions = LayoutOptions.Center,
            };

            var shell = new Border
            {
                Style = (Style)Application.Current!.Resources["InputShell"],
                WidthRequest = 130,
                Content = field,
            };

            var row = new Grid { ColumnSpacing = 10 };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            row.Add(swatch, 0, 0);
            row.Add(label, 1, 0);
            row.Add(shell, 2, 0);

            Rows.Children.Add(row);
        }
    }

    private async void OnSave(object sender, EventArgs e)
    {
        var budgets = new List<Budget>();

        foreach (var (id, field) in _fields)
        {
            var text = (field.Text ?? "").Replace(',', '.').Trim();
            if (text.Length == 0) continue;
            if (!decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var amount)) continue;
            if (amount <= 0) continue;

            budgets.Add(new Budget { Category = id, Monthly = amount });
        }

        _vm.Book.Budgets = budgets;
        await _vm.SaveAsync();
        await Navigation.PopAsync();
    }

    private async void OnClear(object sender, EventArgs e)
    {
        var sure = await DisplayAlert("Clear every budget?",
            "The ceilings go away. Your entries are untouched.", "Clear", "Cancel");
        if (!sure) return;

        _vm.Book.Budgets = new List<Budget>();
        await _vm.SaveAsync();
        Build();
    }
}
