using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class MainPage : ContentPage
{
    private readonly MainViewModel _vm = new();
    private bool _loaded;

    public MainPage()
    {
        InitializeComponent();
        BindingContext = _vm;

        _vm.ChartsChanged += RedrawCharts;
        _vm.EditRequested += tx => Dispatcher.Dispatch(async () => await OpenEntry(tx));
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_loaded) { _vm.Recalculate(); return; }
        _loaded = true;
        await _vm.LoadAsync();
    }

    private void RedrawCharts()
    {
        Dispatcher.Dispatch(() =>
        {
            WedgeView.Invalidate();
            CatView.Invalidate();
            PaceView.Invalidate();
        });
    }

    private Task OpenEntry(Transaction? existing) =>
        Navigation.PushAsync(new EntryPage(_vm, existing));

    private async void OnRecord(object sender, EventArgs e) => await OpenEntry(null);

    private async void OnRowTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Element { BindingContext: TxRow row })
            await OpenEntry(row.Tx);
    }

    private async void OnSettings(object sender, EventArgs e) =>
        await Navigation.PushAsync(new SettingsPage(_vm));

    private async void OnGoals(object sender, EventArgs e) =>
        await Navigation.PushAsync(new GoalsPage(_vm));

    private void OnTabCats(object sender, EventArgs e) => SelectTab(showCats: true);
    private void OnTabPace(object sender, EventArgs e) => SelectTab(showCats: false);

    private void SelectTab(bool showCats)
    {
        CatsPane.IsVisible = showCats;
        PaceView.IsVisible = !showCats;

        var ink = (Color)Application.Current!.Resources["Ink"];
        var muted = (Color)Application.Current!.Resources["Muted"];

        TabCats.TextColor = showCats ? ink : muted;
        TabPace.TextColor = showCats ? muted : ink;
        TabCats.FontAttributes = showCats ? FontAttributes.Bold : FontAttributes.None;
        TabPace.FontAttributes = showCats ? FontAttributes.None : FontAttributes.Bold;

        RedrawCharts();
    }
}
