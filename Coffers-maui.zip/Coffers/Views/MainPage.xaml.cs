using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class MainPage : ContentPage
{
    private readonly MainViewModel _vm = new();
    private bool _loaded;

    public MainPage()
    {
        InitializeComponent();
        BindingContext = _vm;
        _vm.ChartsChanged += RedrawCharts;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        if (_loaded) { _vm.Recalculate(); ConsumePendingAction(); return; }

        _loaded = true;
        await _vm.LoadAsync();
        ConsumePendingAction();
    }

    /// <summary>
    /// The widget's record button opens the app and leaves a note behind. Pick it up
    /// once, after the ledger is loaded, and let the frame settle before pushing a page.
    /// </summary>
    private void ConsumePendingAction()
    {
        if (App.PendingAction is null) return;
        App.PendingAction = null;

        Dispatcher.DispatchDelayed(TimeSpan.FromMilliseconds(220), async () =>
        {
            try { await OpenEntry(null); } catch { }
        });
    }

    private void RedrawCharts()
    {
        Dispatcher.Dispatch(() =>
        {
            WedgeView.Invalidate();
            CatView.Invalidate();
            PaceView.Invalidate();
            BalanceView.Invalidate();
            HeatView.Invalidate();
        });
    }

    // ---------- navigation ----------

    private Task OpenEntry(Transaction? existing) =>
        Navigation.PushAsync(new EntryPage(_vm, existing));

    private async void OnRecord(object sender, EventArgs e)
    {
        _vm.DismissUndo();
        await OpenEntry(null);
    }

    private async void OnRowTapped(object? sender, TappedEventArgs e)
    {
        if (sender is Element { BindingContext: TxRow row })
            await OpenEntry(row.Tx);
    }

    private async void OnSettings(object sender, EventArgs e) =>
        await Navigation.PushAsync(new SettingsPage(_vm));

    private async void OnGoals(object sender, EventArgs e) =>
        await Navigation.PushAsync(new GoalsPage(_vm));

    private async void OnBudgets(object sender, EventArgs e) =>
        await Navigation.PushAsync(new BudgetsPage(_vm));

    private async void OnStanding(object sender, EventArgs e) =>
        await Navigation.PushAsync(new StandingPage(_vm));

    // ---------- search ----------

    private void OnToggleSearch(object sender, EventArgs e)
    {
        SearchShell.IsVisible = !SearchShell.IsVisible;

        if (SearchShell.IsVisible) SearchField.Focus();
        else _vm.SearchText = "";
    }

    // ---------- goals ----------

    private async void OnPutAside(object? sender, EventArgs e)
    {
        if (sender is not Element { BindingContext: GoalRow goal }) return;

        var answer = await DisplayPromptAsync(
            $"Put aside for {goal.Name}",
            "How much are you setting aside? A negative number takes it back out.",
            accept: "Put aside", cancel: "Cancel",
            placeholder: "0", keyboard: Keyboard.Numeric);

        if (string.IsNullOrWhiteSpace(answer)) return;

        if (!decimal.TryParse(answer.Replace(',', '.').Trim(),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var amount))
            return;

        await _vm.PutAsideAsync(goal.Id, amount);
    }

    // ---------- chart tabs ----------

    private void OnTabCats(object sender, EventArgs e) => SelectTab(0);
    private void OnTabPace(object sender, EventArgs e) => SelectTab(1);
    private void OnTabBalance(object sender, EventArgs e) => SelectTab(2);
    private void OnTabDays(object sender, EventArgs e) => SelectTab(3);

    private void SelectTab(int index)
    {
        CatsPane.IsVisible = index == 0;
        PaceView.IsVisible = index == 1;
        BalanceView.IsVisible = index == 2;
        HeatView.IsVisible = index == 3;

        var ink = (Color)Application.Current!.Resources["Ink"];
        var muted = (Color)Application.Current!.Resources["Muted"];
        var tabs = new[] { TabCats, TabPace, TabBalance, TabDays };

        for (var i = 0; i < tabs.Length; i++)
        {
            tabs[i].TextColor = i == index ? ink : muted;
            tabs[i].FontAttributes = i == index ? FontAttributes.Bold : FontAttributes.None;
        }

        RedrawCharts();
    }
}
