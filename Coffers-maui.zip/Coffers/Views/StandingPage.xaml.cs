using Coffers.Models;
using Coffers.Services;
using Coffers.ViewModels;

namespace Coffers.Views;

/// <summary>
/// Two boards. Above, the records you're chasing. Below, your own verdicts on
/// what the money actually bought — the only spending judgement in the app that
/// isn't a number telling you off.
/// </summary>
public partial class StandingPage : ContentPage
{
    private readonly MainViewModel _vm;

    private static Color Res(string key) => (Color)Application.Current!.Resources[key];

    public StandingPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;

        BuildBests();
        BuildVerdicts();
    }

    private void BuildBests()
    {
        var bests = Records.For(_vm.Book);
        BestEmpty.IsVisible = bests.Count == 0;

        foreach (var b in bests)
        {
            var head = new Grid();
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            head.Add(new Label
            {
                Text = b.Title,
                Style = (Style)Application.Current!.Resources["Eyebrow"],
                VerticalOptions = LayoutOptions.Center,
            }, 0, 0);

            head.Add(new Label
            {
                Text = b.Value,
                Style = (Style)Application.Current!.Resources["Figure"],
                FontSize = 17,
                VerticalOptions = LayoutOptions.Center,
            }, 1, 0);

            var body = new VerticalStackLayout { Spacing = 3 };
            body.Add(head);

            body.Add(new Label
            {
                Text = b.When,
                Style = (Style)Application.Current!.Resources["Small"],
                FontSize = 11,
            });

            body.Add(new Label
            {
                Text = b.Chase,
                Style = (Style)Application.Current!.Resources["Small"],
                FontSize = 11.5,
                FontAttributes = b.IsLive ? FontAttributes.Bold : FontAttributes.None,
                TextColor = b.IsLive ? Res("MoneyIn") : Res("Muted"),
                Margin = new Thickness(0, 4, 0, 0),
            });

            BestBox.Children.Add(new Border
            {
                Style = (Style)Application.Current!.Resources["Panel"],
                Padding = new Thickness(15, 13),
                Content = body,
            });
        }
    }

    private void BuildVerdicts()
    {
        var (worth, total) = Judgement.Tally(_vm.Book);
        var rows = Judgement.ByCategory(_vm.Book);
        var cur = _vm.Currency;

        if (total == 0)
        {
            VerdictLead.Text = _vm.Book.Settings.WorthIt
                ? "A week after each larger payment, Coffers asks whether it was worth it. Nothing to show yet — the first question arrives once a payment has had time to settle."
                : "Turned off in Settings. Switch it on and Coffers will ask, a week after each larger payment, whether it was worth it.";
            return;
        }

        var regret = Judgement.Regret(_vm.Book);
        var pct = (int)Math.Round(100.0 * worth / total);

        VerdictLead.Text =
            $"You've judged {total} payment{(total == 1 ? "" : "s")} and called {pct}% of them worth it. " +
            $"The rest came to {Money.Format(regret, cur)}.";

        foreach (var r in rows)
        {
            var head = new Grid();
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            head.Add(new Label
            {
                Text = r.Label,
                Style = (Style)Application.Current!.Resources["Body"],
                FontAttributes = FontAttributes.Bold,
                TextColor = Res("Ink"),
            }, 0, 0);

            head.Add(new Label
            {
                Text = $"{r.Worth} of {r.Total}",
                Style = (Style)Application.Current!.Resources["Small"],
                FontSize = 11,
            }, 1, 0);

            var body = new VerticalStackLayout { Spacing = 6 };
            body.Add(head);

            body.Add(new ProgressBar
            {
                Progress = r.Rate,
                HeightRequest = 4,
                ProgressColor = r.Hue,
            });

            var tail = r.Regret > 0
                ? $"{Money.Format(r.Regret, cur)} you'd rather have back"
                : "Nothing regretted here";

            body.Add(new Label
            {
                Text = tail,
                Style = (Style)Application.Current!.Resources["Small"],
                FontSize = 10.5,
            });

            VerdictBox.Children.Add(body);
        }
    }
}
