using System.Globalization;
using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class GoalsPage : ContentPage
{
    private readonly MainViewModel _vm;
    private readonly List<Row> _rows = new();

    private sealed record Row(string Id, Entry Name, Entry Saved, Entry Target, View Container);

    public GoalsPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;

        foreach (var g in vm.Book.Goals)
            AddRow(g);

        if (_rows.Count == 0) AddRow(new Goal());
    }

    private void AddRow(Goal goal)
    {
        var name = MakeEntry(goal.Name, "What for?", numeric: false);
        var saved = MakeEntry(Num(goal.Saved), "0", numeric: true);
        var target = MakeEntry(Num(goal.Target), "0", numeric: true);

        var remove = new Button
        {
            Text = "Remove",
            Style = (Style)Application.Current!.Resources["Link"],
            HorizontalOptions = LayoutOptions.Start,
            TextColor = (Color)Application.Current!.Resources["MoneyOut"],
            FontSize = 12,
        };

        var pair = new Grid { ColumnSpacing = 10 };
        pair.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
        pair.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
        pair.Add(Labelled("PUT ASIDE", saved), 0, 0);
        pair.Add(Labelled("TARGET", target), 1, 0);

        var body = new VerticalStackLayout { Spacing = 10 };
        body.Add(Shell(name));
        body.Add(pair);
        body.Add(remove);

        var card = new Border
        {
            Style = (Style)Application.Current!.Resources["Panel"],
            Content = body,
        };

        var row = new Row(goal.Id, name, saved, target, card);
        _rows.Add(row);
        GoalBox.Children.Add(card);

        remove.Clicked += (_, _) =>
        {
            _rows.Remove(row);
            GoalBox.Children.Remove(card);
        };
    }

    private static string Num(decimal d) => d.ToString("0.##", CultureInfo.InvariantCulture);

    private static Entry MakeEntry(string text, string placeholder, bool numeric) => new()
    {
        Text = text,
        Placeholder = placeholder,
        HeightRequest = 46,
        Keyboard = numeric ? Keyboard.Numeric : Keyboard.Default,
    };

    private static Border Shell(View content) => new()
    {
        Style = (Style)Application.Current!.Resources["InputShell"],
        Content = content,
    };

    private static View Labelled(string caption, Entry entry)
    {
        var stack = new VerticalStackLayout { Spacing = 5 };
        stack.Add(new Label
        {
            Text = caption,
            Style = (Style)Application.Current!.Resources["Eyebrow"],
        });
        stack.Add(Shell(entry));
        return stack;
    }

    private void OnAdd(object sender, EventArgs e) => AddRow(new Goal());

    private async void OnSave(object sender, EventArgs e)
    {
        var goals = new List<Goal>();

        foreach (var r in _rows)
        {
            var name = (r.Name.Text ?? "").Trim();
            if (name.Length == 0) continue;

            goals.Add(new Goal
            {
                Id = r.Id,
                Name = name,
                Saved = Parse(r.Saved.Text),
                Target = Parse(r.Target.Text),
            });
        }

        _vm.Book.Goals = goals;
        await _vm.SaveAsync();
        await Navigation.PopAsync();
    }

    private static decimal Parse(string? text)
    {
        var clean = (text ?? "0").Replace(',', '.').Trim();
        return decimal.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : 0m;
    }
}
