using System.Globalization;
using Coffers.Models;
using Coffers.ViewModels;

namespace Coffers.Views;

public partial class RecurringPage : ContentPage
{
    private readonly MainViewModel _vm;
    private readonly List<Row> _rows = new();

    private sealed record Row(string Id, string LastPosted, Entry Name, Entry Amount,
                              Picker Category, Picker Day, View Card);

    public RecurringPage(MainViewModel vm)
    {
        InitializeComponent();
        _vm = vm;

        foreach (var r in vm.Book.Recurring) AddRow(r);
        RefreshEmpty();
    }

    private void RefreshEmpty() => EmptyNote.IsVisible = _rows.Count == 0;

    private void AddRow(Recurring model)
    {
        var name = new Entry
        {
            Text = model.Name,
            Placeholder = "Rent, Spotify, gym…",
            HeightRequest = 46,
        };

        var amount = new Entry
        {
            Text = model.Amount > 0 ? model.Amount.ToString("0.##", CultureInfo.InvariantCulture) : "",
            Placeholder = "0",
            Keyboard = Keyboard.Numeric,
            HeightRequest = 46,
        };

        var category = new Picker { HeightRequest = 46, Title = "Category" };
        foreach (var c in Categories.Outgoing) category.Items.Add(c.Label);
        var catIndex = Array.FindIndex(Categories.Outgoing, c => c.Id == model.Category);
        category.SelectedIndex = catIndex >= 0 ? catIndex : 0;

        var day = new Picker { HeightRequest = 46, Title = "Day" };
        for (var d = 1; d <= 28; d++) day.Items.Add($"Day {d}");
        day.SelectedIndex = Math.Clamp(model.DayOfMonth, 1, 28) - 1;

        var remove = new Button
        {
            Text = "Remove",
            Style = (Style)Application.Current!.Resources["Link"],
            TextColor = (Color)Application.Current!.Resources["MoneyOut"],
            HorizontalOptions = LayoutOptions.Start,
            FontSize = 12,
        };

        var pair = new Grid { ColumnSpacing = 10 };
        pair.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
        pair.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
        pair.Add(Shell(amount), 0, 0);
        pair.Add(Shell(day), 1, 0);

        var body = new VerticalStackLayout { Spacing = 10 };
        body.Add(Shell(name));
        body.Add(Shell(category));
        body.Add(pair);
        body.Add(remove);

        var card = new Border
        {
            Style = (Style)Application.Current!.Resources["Panel"],
            Content = body,
        };

        var row = new Row(model.Id, model.LastPosted, name, amount, category, day, card);
        _rows.Add(row);
        Rows.Children.Add(card);

        remove.Clicked += (_, _) =>
        {
            _rows.Remove(row);
            Rows.Children.Remove(card);
            RefreshEmpty();
        };
    }

    private static Border Shell(View content) => new()
    {
        Style = (Style)Application.Current!.Resources["InputShell"],
        Content = content,
    };

    private void OnAdd(object sender, EventArgs e)
    {
        AddRow(new Recurring());
        RefreshEmpty();
    }

    private async void OnSave(object sender, EventArgs e)
    {
        var list = new List<Recurring>();

        foreach (var r in _rows)
        {
            var name = (r.Name.Text ?? "").Trim();
            var text = (r.Amount.Text ?? "").Replace(',', '.').Trim();
            if (name.Length == 0) continue;
            if (!decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var value)) continue;
            if (value <= 0) continue;

            var catIndex = Math.Clamp(r.Category.SelectedIndex, 0, Categories.Outgoing.Length - 1);

            list.Add(new Recurring
            {
                Id = r.Id,
                Name = name,
                Amount = value,
                Category = Categories.Outgoing[catIndex].Id,
                Type = Flow.Out,
                DayOfMonth = Math.Clamp(r.Day.SelectedIndex + 1, 1, 28),
                LastPosted = r.LastPosted,
            });
        }

        _vm.Book.Recurring = list;
        await _vm.SaveAsync();
        await Navigation.PopAsync();
    }
}
